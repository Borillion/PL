package defpackage;

/* renamed from: $r8$java8methods$utility$Long$hashCode$IJ */
public /* synthetic */ class $r8$java8methods$utility$Long$hashCode$IJ {
}
