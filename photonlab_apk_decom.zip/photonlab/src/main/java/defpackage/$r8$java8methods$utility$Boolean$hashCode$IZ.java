package defpackage;

/* renamed from: $r8$java8methods$utility$Boolean$hashCode$IZ */
public /* synthetic */ class $r8$java8methods$utility$Boolean$hashCode$IZ {
}
