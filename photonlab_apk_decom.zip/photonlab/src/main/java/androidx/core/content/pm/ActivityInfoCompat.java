package androidx.core.content.pm;

@Deprecated
public final class ActivityInfoCompat {
    @Deprecated
    public static final int CONFIG_UI_MODE = 512;

    private ActivityInfoCompat() {
    }
}
