package androidx.core.os;

import android.os.Build.VERSION;

public final class CancellationSignal {
    private boolean mCancelInProgress;
    private Object mCancellationSignalObj;
    private boolean mIsCanceled;
    private OnCancelListener mOnCancelListener;

    public interface OnCancelListener {
        void onCancel();
    }

    public boolean isCanceled() {
        boolean z;
        synchronized (this) {
            z = this.mIsCanceled;
        }
        return z;
    }

    public void throwIfCanceled() {
        if (isCanceled()) {
            throw new OperationCanceledException();
        }
    }

    /* JADX WARNING: Missing block: B:9:0x0012, code:
            if (r0 == null) goto L_0x001a;
     */
    /* JADX WARNING: Missing block: B:11:?, code:
            r0.onCancel();
     */
    /* JADX WARNING: Missing block: B:13:0x001a, code:
            if (r1 == null) goto L_0x0033;
     */
    /* JADX WARNING: Missing block: B:15:0x0020, code:
            if (android.os.Build.VERSION.SDK_INT < 16) goto L_0x0033;
     */
    /* JADX WARNING: Missing block: B:16:0x0022, code:
            ((android.os.CancellationSignal) r1).cancel();
     */
    /* JADX WARNING: Missing block: B:17:0x0028, code:
            monitor-enter(r4);
     */
    /* JADX WARNING: Missing block: B:19:?, code:
            r4.mCancelInProgress = false;
            notifyAll();
     */
    /* JADX WARNING: Missing block: B:26:0x0033, code:
            monitor-enter(r4);
     */
    /* JADX WARNING: Missing block: B:28:?, code:
            r4.mCancelInProgress = false;
            notifyAll();
     */
    /* JADX WARNING: Missing block: B:29:0x0039, code:
            monitor-exit(r4);
     */
    /* JADX WARNING: Missing block: B:30:0x003a, code:
            return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void cancel() {
        synchronized (this) {
            if (this.mIsCanceled) {
                return;
            }
            this.mIsCanceled = true;
            this.mCancelInProgress = true;
            OnCancelListener onCancelListener = this.mOnCancelListener;
            Object obj = this.mCancellationSignalObj;
        }
    }

    public void setOnCancelListener(OnCancelListener onCancelListener) {
        synchronized (this) {
            waitForCancelFinishedLocked();
            if (this.mOnCancelListener == onCancelListener) {
                return;
            }
            this.mOnCancelListener = onCancelListener;
            if (!this.mIsCanceled || onCancelListener == null) {
                return;
            }
            onCancelListener.onCancel();
        }
    }

    public Object getCancellationSignalObject() {
        if (VERSION.SDK_INT < 16) {
            return null;
        }
        Object obj;
        synchronized (this) {
            if (this.mCancellationSignalObj == null) {
                this.mCancellationSignalObj = new android.os.CancellationSignal();
                if (this.mIsCanceled) {
                    ((android.os.CancellationSignal) this.mCancellationSignalObj).cancel();
                }
            }
            obj = this.mCancellationSignalObj;
        }
        return obj;
    }

    /* JADX WARNING: Removed duplicated region for block: B:0:0x0000 A:{LOOP_START, LOOP:0: B:0:0x0000->B:6:0x0000, ExcHandler: java.lang.InterruptedException (unused java.lang.InterruptedException), Splitter: B:2:0x0004} */
    /* JADX WARNING: Can't wrap try/catch for R(5:2|3|4|9|0) */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void waitForCancelFinishedLocked() {
        while (this.mCancelInProgress) {
            wait();
        }
    }
}
