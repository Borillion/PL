package androidx.core.graphics;

import android.graphics.Path;
import android.util.Log;
import androidx.annotation.RestrictTo;
import androidx.annotation.RestrictTo.Scope;
import java.util.ArrayList;

@RestrictTo({Scope.LIBRARY_GROUP})
public class PathParser {
    private static final String LOGTAG = "PathParser";

    private static class ExtractFloatResult {
        int mEndPosition;
        boolean mEndWithNegOrDot;

        ExtractFloatResult() {
        }
    }

    public static class PathDataNode {
        @RestrictTo({Scope.LIBRARY_GROUP})
        public float[] mParams;
        @RestrictTo({Scope.LIBRARY_GROUP})
        public char mType;

        PathDataNode(char c, float[] fArr) {
            this.mType = c;
            this.mParams = fArr;
        }

        PathDataNode(PathDataNode pathDataNode) {
            this.mType = pathDataNode.mType;
            float[] fArr = pathDataNode.mParams;
            this.mParams = PathParser.copyOfRange(fArr, 0, fArr.length);
        }

        public static void nodesToPath(PathDataNode[] pathDataNodeArr, Path path) {
            float[] fArr = new float[6];
            char c = 'm';
            for (int i = 0; i < pathDataNodeArr.length; i++) {
                addCommand(path, fArr, c, pathDataNodeArr[i].mType, pathDataNodeArr[i].mParams);
                c = pathDataNodeArr[i].mType;
            }
        }

        public void interpolatePathDataNode(PathDataNode pathDataNode, PathDataNode pathDataNode2, float f) {
            int i = 0;
            while (true) {
                float[] fArr = pathDataNode.mParams;
                if (i < fArr.length) {
                    this.mParams[i] = (fArr[i] * (1.0f - f)) + (pathDataNode2.mParams[i] * f);
                    i++;
                } else {
                    return;
                }
            }
        }

        /* JADX WARNING: Missing block: B:2:0x001e, code:
            r19 = 2;
     */
        /* JADX WARNING: Missing block: B:8:0x0035, code:
            r19 = r6;
     */
        /* JADX WARNING: Missing block: B:9:0x0037, code:
            r8 = r0;
            r7 = r1;
            r20 = r4;
            r21 = r5;
            r9 = 0;
            r0 = r26;
     */
        /* JADX WARNING: Missing block: B:11:0x0041, code:
            if (r9 >= r12.length) goto L_0x0308;
     */
        /* JADX WARNING: Missing block: B:13:0x0045, code:
            if (r11 == 'A') goto L_0x02c2;
     */
        /* JADX WARNING: Missing block: B:15:0x0049, code:
            if (r11 == 'C') goto L_0x0297;
     */
        /* JADX WARNING: Missing block: B:17:0x004d, code:
            if (r11 == 'H') goto L_0x0289;
     */
        /* JADX WARNING: Missing block: B:19:0x0051, code:
            if (r11 == 'Q') goto L_0x0268;
     */
        /* JADX WARNING: Missing block: B:21:0x0055, code:
            if (r11 == 'V') goto L_0x025a;
     */
        /* JADX WARNING: Missing block: B:23:0x0059, code:
            if (r11 == 'a') goto L_0x020d;
     */
        /* JADX WARNING: Missing block: B:25:0x005d, code:
            if (r11 == 'c') goto L_0x01e0;
     */
        /* JADX WARNING: Missing block: B:27:0x0061, code:
            if (r11 == 'h') goto L_0x01d3;
     */
        /* JADX WARNING: Missing block: B:29:0x0065, code:
            if (r11 == 'q') goto L_0x01b4;
     */
        /* JADX WARNING: Missing block: B:31:0x0069, code:
            if (r11 == 'v') goto L_0x01a8;
     */
        /* JADX WARNING: Missing block: B:33:0x006d, code:
            if (r11 == 'L') goto L_0x0197;
     */
        /* JADX WARNING: Missing block: B:35:0x0071, code:
            if (r11 == 'M') goto L_0x0177;
     */
        /* JADX WARNING: Missing block: B:37:0x0077, code:
            if (r11 == 'S') goto L_0x0146;
     */
        /* JADX WARNING: Missing block: B:39:0x007b, code:
            if (r11 == 'T') goto L_0x011f;
     */
        /* JADX WARNING: Missing block: B:41:0x007f, code:
            if (r11 == 'l') goto L_0x010c;
     */
        /* JADX WARNING: Missing block: B:43:0x0083, code:
            if (r11 == 'm') goto L_0x00ef;
     */
        /* JADX WARNING: Missing block: B:45:0x0087, code:
            if (r11 == 's') goto L_0x00b9;
     */
        /* JADX WARNING: Missing block: B:47:0x008b, code:
            if (r11 == 't') goto L_0x0091;
     */
        /* JADX WARNING: Missing block: B:48:0x008d, code:
            r22 = r9;
     */
        /* JADX WARNING: Missing block: B:49:0x0091, code:
            if (r0 == 'q') goto L_0x009f;
     */
        /* JADX WARNING: Missing block: B:51:0x0095, code:
            if (r0 == 't') goto L_0x009f;
     */
        /* JADX WARNING: Missing block: B:52:0x0097, code:
            if (r0 == 'Q') goto L_0x009f;
     */
        /* JADX WARNING: Missing block: B:53:0x0099, code:
            if (r0 != 'T') goto L_0x009c;
     */
        /* JADX WARNING: Missing block: B:54:0x009c, code:
            r0 = 0.0f;
            r4 = 0.0f;
     */
        /* JADX WARNING: Missing block: B:55:0x009f, code:
            r4 = r8 - r2;
            r0 = r7 - r3;
     */
        /* JADX WARNING: Missing block: B:56:0x00a3, code:
            r1 = r9 + 0;
            r3 = r9 + 1;
            r10.rQuadTo(r4, r0, r12[r1], r12[r3]);
            r4 = r4 + r8;
            r0 = r0 + r7;
            r8 = r8 + r12[r1];
            r7 = r7 + r12[r3];
            r3 = r0;
            r2 = r4;
     */
        /* JADX WARNING: Missing block: B:57:0x00b9, code:
            if (r0 == 'c') goto L_0x00c7;
     */
        /* JADX WARNING: Missing block: B:59:0x00bd, code:
            if (r0 == 's') goto L_0x00c7;
     */
        /* JADX WARNING: Missing block: B:60:0x00bf, code:
            if (r0 == 'C') goto L_0x00c7;
     */
        /* JADX WARNING: Missing block: B:61:0x00c1, code:
            if (r0 != 'S') goto L_0x00c4;
     */
        /* JADX WARNING: Missing block: B:62:0x00c4, code:
            r1 = 0.0f;
            r2 = 0.0f;
     */
        /* JADX WARNING: Missing block: B:63:0x00c7, code:
            r0 = r8 - r2;
            r2 = r7 - r3;
            r1 = r0;
     */
        /* JADX WARNING: Missing block: B:64:0x00cd, code:
            r13 = r9 + 0;
            r14 = r9 + 1;
            r15 = r9 + 2;
            r22 = r9 + 3;
            r24.rCubicTo(r1, r2, r12[r13], r12[r14], r12[r15], r12[r22]);
            r0 = r12[r13] + r8;
            r1 = r12[r14] + r7;
            r8 = r8 + r12[r15];
            r2 = r12[r22];
     */
        /* JADX WARNING: Missing block: B:65:0x00ef, code:
            r0 = r9 + 0;
            r8 = r8 + r12[r0];
            r1 = r9 + 1;
            r7 = r7 + r12[r1];
     */
        /* JADX WARNING: Missing block: B:66:0x00f9, code:
            if (r9 <= 0) goto L_0x0103;
     */
        /* JADX WARNING: Missing block: B:67:0x00fb, code:
            r10.rLineTo(r12[r0], r12[r1]);
     */
        /* JADX WARNING: Missing block: B:68:0x0103, code:
            r10.rMoveTo(r12[r0], r12[r1]);
     */
        /* JADX WARNING: Missing block: B:69:0x010c, code:
            r0 = r9 + 0;
            r4 = r9 + 1;
            r10.rLineTo(r12[r0], r12[r4]);
            r8 = r8 + r12[r0];
            r0 = r12[r4];
     */
        /* JADX WARNING: Missing block: B:70:0x011c, code:
            r7 = r7 + r0;
     */
        /* JADX WARNING: Missing block: B:71:0x011f, code:
            if (r0 == 'q') goto L_0x0129;
     */
        /* JADX WARNING: Missing block: B:73:0x0123, code:
            if (r0 == 't') goto L_0x0129;
     */
        /* JADX WARNING: Missing block: B:74:0x0125, code:
            if (r0 == 'Q') goto L_0x0129;
     */
        /* JADX WARNING: Missing block: B:75:0x0127, code:
            if (r0 != 'T') goto L_0x012f;
     */
        /* JADX WARNING: Missing block: B:76:0x0129, code:
            r8 = (r8 * 2.0f) - r2;
            r7 = (r7 * 2.0f) - r3;
     */
        /* JADX WARNING: Missing block: B:77:0x012f, code:
            r0 = r9 + 0;
            r2 = r9 + 1;
            r10.quadTo(r8, r7, r12[r0], r12[r2]);
            r0 = r12[r0];
            r1 = r12[r2];
            r3 = r7;
            r2 = r8;
            r22 = r9;
            r8 = r0;
            r7 = r1;
     */
        /* JADX WARNING: Missing block: B:78:0x0146, code:
            if (r0 == 'c') goto L_0x0150;
     */
        /* JADX WARNING: Missing block: B:80:0x014a, code:
            if (r0 == 's') goto L_0x0150;
     */
        /* JADX WARNING: Missing block: B:81:0x014c, code:
            if (r0 == 'C') goto L_0x0150;
     */
        /* JADX WARNING: Missing block: B:82:0x014e, code:
            if (r0 != 'S') goto L_0x0156;
     */
        /* JADX WARNING: Missing block: B:83:0x0150, code:
            r8 = (r8 * 2.0f) - r2;
            r7 = (r7 * 2.0f) - r3;
     */
        /* JADX WARNING: Missing block: B:84:0x0156, code:
            r2 = r7;
            r7 = r9 + 0;
            r8 = r9 + 1;
            r13 = r9 + 2;
            r14 = r9 + 3;
            r24.cubicTo(r8, r2, r12[r7], r12[r8], r12[r13], r12[r14]);
            r0 = r12[r7];
            r1 = r12[r8];
            r8 = r12[r13];
            r7 = r12[r14];
     */
        /* JADX WARNING: Missing block: B:85:0x0177, code:
            r0 = r9 + 0;
            r8 = r12[r0];
            r1 = r9 + 1;
            r7 = r12[r1];
     */
        /* JADX WARNING: Missing block: B:86:0x017f, code:
            if (r9 <= 0) goto L_0x018a;
     */
        /* JADX WARNING: Missing block: B:87:0x0181, code:
            r10.lineTo(r12[r0], r12[r1]);
     */
        /* JADX WARNING: Missing block: B:88:0x018a, code:
            r10.moveTo(r12[r0], r12[r1]);
     */
        /* JADX WARNING: Missing block: B:89:0x0191, code:
            r21 = r7;
            r20 = r8;
     */
        /* JADX WARNING: Missing block: B:90:0x0197, code:
            r0 = r9 + 0;
            r4 = r9 + 1;
            r10.lineTo(r12[r0], r12[r4]);
            r8 = r12[r0];
            r7 = r12[r4];
     */
        /* JADX WARNING: Missing block: B:91:0x01a8, code:
            r0 = r9 + 0;
            r10.rLineTo(0.0f, r12[r0]);
            r0 = r12[r0];
     */
        /* JADX WARNING: Missing block: B:92:0x01b4, code:
            r0 = r9 + 0;
            r2 = r9 + 1;
            r4 = r9 + 2;
            r6 = r9 + 3;
            r10.rQuadTo(r12[r0], r12[r2], r12[r4], r12[r6]);
            r0 = r12[r0] + r8;
            r1 = r12[r2] + r7;
            r8 = r8 + r12[r4];
            r2 = r12[r6];
     */
        /* JADX WARNING: Missing block: B:93:0x01d3, code:
            r0 = r9 + 0;
            r10.rLineTo(r12[r0], 0.0f);
            r8 = r8 + r12[r0];
     */
        /* JADX WARNING: Missing block: B:94:0x01e0, code:
            r13 = r9 + 2;
            r14 = r9 + 3;
            r15 = r9 + 4;
            r22 = r9 + 5;
            r24.rCubicTo(r12[r9 + 0], r12[r9 + 1], r12[r13], r12[r14], r12[r15], r12[r22]);
            r0 = r12[r13] + r8;
            r1 = r12[r14] + r7;
            r8 = r8 + r12[r15];
            r2 = r12[r22];
     */
        /* JADX WARNING: Missing block: B:95:0x0208, code:
            r7 = r7 + r2;
     */
        /* JADX WARNING: Missing block: B:96:0x0209, code:
            r2 = r0;
            r3 = r1;
     */
        /* JADX WARNING: Missing block: B:97:0x020d, code:
            r13 = r9 + 5;
            r3 = r12[r13] + r8;
            r14 = r9 + 6;
            r4 = r12[r14] + r7;
            r5 = r12[r9 + 0];
            r6 = r12[r9 + 1];
            r15 = r12[r9 + 2];
     */
        /* JADX WARNING: Missing block: B:98:0x022c, code:
            if (r12[r9 + 3] == 0.0f) goto L_0x0231;
     */
        /* JADX WARNING: Missing block: B:99:0x022e, code:
            r22 = true;
     */
        /* JADX WARNING: Missing block: B:100:0x0231, code:
            r22 = false;
     */
        /* JADX WARNING: Missing block: B:102:0x0239, code:
            if (r12[r9 + 4] == 0.0f) goto L_0x023e;
     */
        /* JADX WARNING: Missing block: B:103:0x023b, code:
            r23 = true;
     */
        /* JADX WARNING: Missing block: B:104:0x023e, code:
            r23 = false;
     */
        /* JADX WARNING: Missing block: B:105:0x0240, code:
            r1 = r8;
            r2 = r7;
            r11 = r7;
            r7 = r15;
            r15 = r8;
            r8 = r22;
            r22 = r9;
            drawArc(r24, r1, r2, r3, r4, r5, r6, r7, r8, r23);
            r8 = r15 + r12[r13];
            r7 = r11 + r12[r14];
     */
        /* JADX WARNING: Missing block: B:106:0x025a, code:
            r22 = r9;
            r9 = r22 + 0;
            r10.lineTo(r8, r12[r9]);
            r7 = r12[r9];
     */
        /* JADX WARNING: Missing block: B:107:0x0268, code:
            r22 = r9;
            r9 = r22 + 0;
            r1 = r22 + 1;
            r3 = r22 + 2;
            r5 = r22 + 3;
            r10.quadTo(r12[r9], r12[r1], r12[r3], r12[r5]);
            r0 = r12[r9];
            r1 = r12[r1];
            r8 = r12[r3];
            r7 = r12[r5];
            r2 = r0;
            r3 = r1;
     */
        /* JADX WARNING: Missing block: B:108:0x0289, code:
            r22 = r9;
            r9 = r22 + 0;
            r10.lineTo(r12[r9], r7);
            r8 = r12[r9];
     */
        /* JADX WARNING: Missing block: B:109:0x0297, code:
            r22 = r9;
            r9 = r22 + 2;
            r7 = r22 + 3;
            r8 = r22 + 4;
            r11 = r22 + 5;
            r0 = r24;
            r0.cubicTo(r12[r22 + 0], r12[r22 + 1], r12[r9], r12[r7], r12[r8], r12[r11]);
            r8 = r12[r8];
            r0 = r12[r11];
            r1 = r12[r9];
            r2 = r12[r7];
            r7 = r0;
            r3 = r2;
            r2 = r1;
     */
        /* JADX WARNING: Missing block: B:110:0x02c2, code:
            r11 = r7;
            r15 = r8;
            r22 = r9;
            r13 = r22 + 5;
            r3 = r12[r13];
            r14 = r22 + 6;
            r4 = r12[r14];
            r5 = r12[r22 + 0];
            r6 = r12[r22 + 1];
            r7 = r12[r22 + 2];
     */
        /* JADX WARNING: Missing block: B:111:0x02e1, code:
            if (r12[r22 + 3] == 0.0f) goto L_0x02e5;
     */
        /* JADX WARNING: Missing block: B:112:0x02e3, code:
            r8 = true;
     */
        /* JADX WARNING: Missing block: B:113:0x02e5, code:
            r8 = false;
     */
        /* JADX WARNING: Missing block: B:115:0x02ec, code:
            if (r12[r22 + 4] == 0.0f) goto L_0x02f0;
     */
        /* JADX WARNING: Missing block: B:116:0x02ee, code:
            r9 = true;
     */
        /* JADX WARNING: Missing block: B:117:0x02f0, code:
            r9 = false;
     */
        /* JADX WARNING: Missing block: B:118:0x02f1, code:
            drawArc(r24, r15, r11, r3, r4, r5, r6, r7, r8, r9);
            r8 = r12[r13];
            r7 = r12[r14];
     */
        /* JADX WARNING: Missing block: B:119:0x02fc, code:
            r3 = r7;
            r2 = r8;
     */
        /* JADX WARNING: Missing block: B:120:0x02fe, code:
            r9 = r22 + r19;
            r0 = r27;
            r11 = r0;
            r13 = 0;
     */
        /* JADX WARNING: Missing block: B:121:0x0308, code:
            r11 = r7;
            r25[r13] = r8;
            r25[1] = r11;
            r25[2] = r2;
            r25[3] = r3;
            r25[4] = r20;
            r25[5] = r21;
     */
        /* JADX WARNING: Missing block: B:122:0x0319, code:
            return;
     */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private static void addCommand(Path path, float[] fArr, char c, char c2, float[] fArr2) {
            Path path2 = path;
            char c3 = c2;
            float[] fArr3 = fArr2;
            int i = 0;
            float f = fArr[0];
            float f2 = fArr[1];
            float f3 = fArr[2];
            float f4 = fArr[3];
            float f5 = fArr[4];
            float f6 = fArr[5];
            int i2;
            int i3;
            switch (c3) {
                case 'A':
                case 'a':
                    i2 = 7;
                    break;
                case 'C':
                case 'c':
                    i2 = 6;
                    break;
                case 'H':
                case 'V':
                case 'h':
                case 'v':
                    i3 = 1;
                    break;
                case 'Q':
                case 'S':
                case 'q':
                case 's':
                    i3 = 4;
                    break;
                case 'Z':
                case 'z':
                    path.close();
                    path2.moveTo(f5, f6);
                    f = f5;
                    f3 = f;
                    f2 = f6;
                    f4 = f2;
                    break;
            }
        }

        private static void drawArc(Path path, float f, float f2, float f3, float f4, float f5, float f6, float f7, boolean z, boolean z2) {
            float f8 = f;
            float f9 = f3;
            float f10 = f5;
            float f11 = f6;
            boolean z3 = z2;
            double toRadians = Math.toRadians((double) f7);
            double cos = Math.cos(toRadians);
            double sin = Math.sin(toRadians);
            double d = (double) f8;
            double d2 = d * cos;
            double d3 = d;
            d = (double) f2;
            double d4 = (double) f10;
            d2 = (d2 + (d * sin)) / d4;
            double d5 = (((double) (-f8)) * sin) + (d * cos);
            double d6 = d;
            d = (double) f11;
            double d7 = d5 / d;
            d5 = (double) f4;
            double d8 = ((((double) f9) * cos) + (d5 * sin)) / d4;
            double d9 = d4;
            d4 = ((((double) (-f9)) * sin) + (d5 * cos)) / d;
            d5 = d2 - d8;
            double d10 = d7 - d4;
            double d11 = (d2 + d8) / 2.0d;
            double d12 = (d7 + d4) / 2.0d;
            double d13 = sin;
            sin = (d5 * d5) + (d10 * d10);
            String str = "PathParser";
            if (sin == 0.0d) {
                Log.w(str, " Points are coincident");
                return;
            }
            double d14 = (1.0d / sin) - 0.25d;
            if (d14 < 0.0d) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Points are too far apart ");
                stringBuilder.append(sin);
                Log.w(str, stringBuilder.toString());
                f8 = (float) (Math.sqrt(sin) / 1.99999d);
                drawArc(path, f, f2, f3, f4, f10 * f8, f6 * f8, f7, z, z2);
                return;
            }
            sin = Math.sqrt(d14);
            d5 *= sin;
            sin *= d10;
            boolean z4 = z2;
            if (z == z4) {
                d11 -= sin;
                d12 += d5;
            } else {
                d11 += sin;
                d12 -= d5;
            }
            d7 = Math.atan2(d7 - d12, d2 - d11);
            double atan2 = Math.atan2(d4 - d12, d8 - d11) - d7;
            int i = (atan2 > 0.0d ? 1 : (atan2 == 0.0d ? 0 : -1));
            if (z4 != (i >= 0)) {
                atan2 = i > 0 ? atan2 - 6.283185307179586d : atan2 + 6.283185307179586d;
            }
            d11 *= d9;
            d12 *= d;
            arcToBezier(path, (d11 * cos) - (d12 * d13), (d11 * d13) + (d12 * cos), d9, d, d3, d6, toRadians, d7, atan2);
        }

        private static void arcToBezier(Path path, double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8, double d9) {
            double d10 = d3;
            int ceil = (int) Math.ceil(Math.abs((d9 * 4.0d) / 3.141592653589793d));
            double cos = Math.cos(d7);
            double sin = Math.sin(d7);
            double cos2 = Math.cos(d8);
            double sin2 = Math.sin(d8);
            double d11 = -d10;
            double d12 = d11 * cos;
            double d13 = d4 * sin;
            double d14 = (d12 * sin2) - (d13 * cos2);
            d11 *= sin;
            double d15 = d4 * cos;
            sin2 = (sin2 * d11) + (cos2 * d15);
            cos2 = d9 / ((double) ceil);
            double d16 = d6;
            double d17 = sin2;
            double d18 = d14;
            int i = 0;
            double d19 = d5;
            d14 = d8;
            while (i < ceil) {
                double d20 = d14 + cos2;
                double sin3 = Math.sin(d20);
                double cos3 = Math.cos(d20);
                double d21 = (d + ((d10 * cos) * cos3)) - (d13 * sin3);
                d10 = (d2 + ((d10 * sin) * cos3)) + (d15 * sin3);
                double d22 = (d12 * sin3) - (d13 * cos3);
                sin3 = (sin3 * d11) + (cos3 * d15);
                d14 = d20 - d14;
                cos3 = Math.tan(d14 / 2.0d);
                d14 = (Math.sin(d14) * (Math.sqrt(((cos3 * 3.0d) * cos3) + 4.0d) - 1.0d)) / 3.0d;
                int i2 = ceil;
                double d23 = cos;
                double d24 = d19 + (d18 * d14);
                d7 = sin;
                double d25 = d16 + (d17 * d14);
                d4 = cos2;
                double d26 = d21 - (d14 * d22);
                int i3 = i2;
                d19 = d11;
                double d27 = d10 - (d14 * sin3);
                path.rLineTo(0.0f, 0.0f);
                path.cubicTo((float) d24, (float) d25, (float) d26, (float) d27, (float) d21, (float) d10);
                i++;
                cos2 = d4;
                ceil = i3;
                sin = d7;
                d16 = d10;
                d11 = d19;
                d14 = d20;
                d17 = sin3;
                d18 = d22;
                cos = d23;
                d10 = d3;
                d19 = d21;
                d21 = 4.0d;
            }
        }
    }

    static float[] copyOfRange(float[] fArr, int i, int i2) {
        if (i <= i2) {
            int length = fArr.length;
            if (i < 0 || i > length) {
                throw new ArrayIndexOutOfBoundsException();
            }
            i2 -= i;
            length = Math.min(i2, length - i);
            Object obj = new float[i2];
            System.arraycopy(fArr, i, obj, 0, length);
            return obj;
        }
        throw new IllegalArgumentException();
    }

    public static Path createPathFromPathData(String str) {
        Path path = new Path();
        PathDataNode[] createNodesFromPathData = createNodesFromPathData(str);
        if (createNodesFromPathData == null) {
            return null;
        }
        try {
            PathDataNode.nodesToPath(createNodesFromPathData, path);
            return path;
        } catch (Throwable e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error in parsing ");
            stringBuilder.append(str);
            throw new RuntimeException(stringBuilder.toString(), e);
        }
    }

    public static PathDataNode[] createNodesFromPathData(String str) {
        if (str == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        int i = 1;
        int i2 = 0;
        while (i < str.length()) {
            i = nextStart(str, i);
            String trim = str.substring(i2, i).trim();
            if (trim.length() > 0) {
                addNode(arrayList, trim.charAt(0), getFloats(trim));
            }
            i2 = i;
            i++;
        }
        if (i - i2 == 1 && i2 < str.length()) {
            addNode(arrayList, str.charAt(i2), new float[0]);
        }
        return (PathDataNode[]) arrayList.toArray(new PathDataNode[arrayList.size()]);
    }

    public static PathDataNode[] deepCopyNodes(PathDataNode[] pathDataNodeArr) {
        if (pathDataNodeArr == null) {
            return null;
        }
        PathDataNode[] pathDataNodeArr2 = new PathDataNode[pathDataNodeArr.length];
        for (int i = 0; i < pathDataNodeArr.length; i++) {
            pathDataNodeArr2[i] = new PathDataNode(pathDataNodeArr[i]);
        }
        return pathDataNodeArr2;
    }

    /* JADX WARNING: Missing block: B:17:0x002c, code:
            return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean canMorph(PathDataNode[] pathDataNodeArr, PathDataNode[] pathDataNodeArr2) {
        if (pathDataNodeArr == null || pathDataNodeArr2 == null || pathDataNodeArr.length != pathDataNodeArr2.length) {
            return false;
        }
        int i = 0;
        while (i < pathDataNodeArr.length) {
            if (pathDataNodeArr[i].mType != pathDataNodeArr2[i].mType || pathDataNodeArr[i].mParams.length != pathDataNodeArr2[i].mParams.length) {
                return false;
            }
            i++;
        }
        return true;
    }

    public static void updateNodes(PathDataNode[] pathDataNodeArr, PathDataNode[] pathDataNodeArr2) {
        for (int i = 0; i < pathDataNodeArr2.length; i++) {
            pathDataNodeArr[i].mType = pathDataNodeArr2[i].mType;
            for (int i2 = 0; i2 < pathDataNodeArr2[i].mParams.length; i2++) {
                pathDataNodeArr[i].mParams[i2] = pathDataNodeArr2[i].mParams[i2];
            }
        }
    }

    private static int nextStart(String str, int i) {
        while (i < str.length()) {
            char charAt = str.charAt(i);
            if (((charAt - 65) * (charAt - 90) <= 0 || (charAt - 97) * (charAt - 122) <= 0) && charAt != 'e' && charAt != 'E') {
                return i;
            }
            i++;
        }
        return i;
    }

    private static void addNode(ArrayList<PathDataNode> arrayList, char c, float[] fArr) {
        arrayList.add(new PathDataNode(c, fArr));
    }

    private static float[] getFloats(String str) {
        if (str.charAt(0) == 'z' || str.charAt(0) == 'Z') {
            return new float[0];
        }
        try {
            float[] fArr = new float[str.length()];
            ExtractFloatResult extractFloatResult = new ExtractFloatResult();
            int length = str.length();
            int i = 1;
            int i2 = 0;
            while (i < length) {
                extract(str, i, extractFloatResult);
                int i3 = extractFloatResult.mEndPosition;
                if (i < i3) {
                    int i4 = i2 + 1;
                    fArr[i2] = Float.parseFloat(str.substring(i, i3));
                    i2 = i4;
                }
                i = extractFloatResult.mEndWithNegOrDot ? i3 : i3 + 1;
            }
            return copyOfRange(fArr, 0, i2);
        } catch (Throwable e) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("error in parsing \"");
            stringBuilder.append(str);
            stringBuilder.append("\"");
            throw new RuntimeException(stringBuilder.toString(), e);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x003a A:{LOOP_END, LOOP:0: B:1:0x0007->B:20:0x003a} */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x003d A:{SYNTHETIC} */
    /* JADX WARNING: Missing block: B:16:0x0031, code:
            r2 = false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void extract(String str, int i, ExtractFloatResult extractFloatResult) {
        extractFloatResult.mEndWithNegOrDot = false;
        int i2 = i;
        boolean z = false;
        boolean z2 = z;
        boolean z3 = z2;
        while (i2 < str.length()) {
            char charAt = str.charAt(i2);
            if (charAt != ' ') {
                if (charAt == 'E' || charAt == 'e') {
                    z = true;
                    if (z3) {
                        i2++;
                    } else {
                        extractFloatResult.mEndPosition = i2;
                    }
                }
                switch (charAt) {
                    case ',':
                        break;
                    case '-':
                        if (!(i2 == i || z)) {
                            extractFloatResult.mEndWithNegOrDot = true;
                        }
                    case '.':
                        if (!z2) {
                            z = false;
                            z2 = true;
                            break;
                        }
                        extractFloatResult.mEndWithNegOrDot = true;
                }
            }
            z = false;
            z3 = true;
            if (z3) {
            }
        }
        extractFloatResult.mEndPosition = i2;
    }

    private PathParser() {
    }
}
