package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;
import androidx.annotation.RestrictTo;
import androidx.annotation.RestrictTo.Scope;
import androidx.core.view.ViewCompat;

@RestrictTo({Scope.LIBRARY})
public class ContentFrameLayout extends FrameLayout {
    private OnAttachListener mAttachListener;
    private final Rect mDecorPadding;
    private TypedValue mFixedHeightMajor;
    private TypedValue mFixedHeightMinor;
    private TypedValue mFixedWidthMajor;
    private TypedValue mFixedWidthMinor;
    private TypedValue mMinWidthMajor;
    private TypedValue mMinWidthMinor;

    public interface OnAttachListener {
        void onAttachedFromWindow();

        void onDetachedFromWindow();
    }

    public ContentFrameLayout(Context context) {
        this(context, null);
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mDecorPadding = new Rect();
    }

    @RestrictTo({Scope.LIBRARY_GROUP})
    public void dispatchFitSystemWindows(Rect rect) {
        fitSystemWindows(rect);
    }

    public void setAttachListener(OnAttachListener onAttachListener) {
        this.mAttachListener = onAttachListener;
    }

    @RestrictTo({Scope.LIBRARY_GROUP})
    public void setDecorPadding(int i, int i2, int i3, int i4) {
        this.mDecorPadding.set(i, i2, i3, i4);
        if (ViewCompat.isLaidOut(this)) {
            requestLayout();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:39:0x0096  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x00e4  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x00f0  */
    /* JADX WARNING: Removed duplicated region for block: B:65:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x00f8  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0050  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x006d  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00c0  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00bd  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x00d2  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x00cc  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x00e4  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x00f0  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x00f8  */
    /* JADX WARNING: Removed duplicated region for block: B:65:? A:{SYNTHETIC, RETURN} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void onMeasure(int i, int i2) {
        int i3;
        Object obj;
        TypedValue typedValue;
        float dimension;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        Object obj2 = 1;
        Object obj3 = displayMetrics.widthPixels < displayMetrics.heightPixels ? 1 : null;
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        if (mode == Integer.MIN_VALUE) {
            TypedValue typedValue2 = obj3 != null ? this.mFixedWidthMinor : this.mFixedWidthMajor;
            if (!(typedValue2 == null || typedValue2.type == 0)) {
                float dimension2;
                if (typedValue2.type == 5) {
                    dimension2 = typedValue2.getDimension(displayMetrics);
                } else if (typedValue2.type == 6) {
                    dimension2 = typedValue2.getFraction((float) displayMetrics.widthPixels, (float) displayMetrics.widthPixels);
                } else {
                    i3 = 0;
                    if (i3 > 0) {
                        i3 = MeasureSpec.makeMeasureSpec(Math.min(i3 - (this.mDecorPadding.left + this.mDecorPadding.right), MeasureSpec.getSize(i)), 1073741824);
                        obj = 1;
                        if (mode2 == Integer.MIN_VALUE) {
                            TypedValue typedValue3 = obj3 != null ? this.mFixedHeightMajor : this.mFixedHeightMinor;
                            if (!(typedValue3 == null || typedValue3.type == 0)) {
                                float dimension3;
                                if (typedValue3.type == 5) {
                                    dimension3 = typedValue3.getDimension(displayMetrics);
                                } else if (typedValue3.type == 6) {
                                    dimension3 = typedValue3.getFraction((float) displayMetrics.heightPixels, (float) displayMetrics.heightPixels);
                                } else {
                                    mode2 = 0;
                                    if (mode2 > 0) {
                                        i2 = MeasureSpec.makeMeasureSpec(Math.min(mode2 - (this.mDecorPadding.top + this.mDecorPadding.bottom), MeasureSpec.getSize(i2)), 1073741824);
                                    }
                                }
                                mode2 = (int) dimension3;
                                if (mode2 > 0) {
                                }
                            }
                        }
                        super.onMeasure(i3, i2);
                        mode2 = getMeasuredWidth();
                        i3 = MeasureSpec.makeMeasureSpec(mode2, 1073741824);
                        if (obj == null && mode == Integer.MIN_VALUE) {
                            typedValue = obj3 == null ? this.mMinWidthMinor : this.mMinWidthMajor;
                            if (!(typedValue == null || typedValue.type == 0)) {
                                if (typedValue.type != 5) {
                                    dimension = typedValue.getDimension(displayMetrics);
                                } else if (typedValue.type == 6) {
                                    dimension = typedValue.getFraction((float) displayMetrics.widthPixels, (float) displayMetrics.widthPixels);
                                } else {
                                    i = 0;
                                    if (i > 0) {
                                        i -= this.mDecorPadding.left + this.mDecorPadding.right;
                                    }
                                    if (mode2 < i) {
                                        i3 = MeasureSpec.makeMeasureSpec(i, 1073741824);
                                        if (obj2 != null) {
                                            super.onMeasure(i3, i2);
                                            return;
                                        }
                                        return;
                                    }
                                }
                                i = (int) dimension;
                                if (i > 0) {
                                }
                                if (mode2 < i) {
                                }
                            }
                        }
                        obj2 = null;
                        if (obj2 != null) {
                        }
                    }
                }
                i3 = (int) dimension2;
                if (i3 > 0) {
                }
            }
        }
        i3 = i;
        obj = null;
        if (mode2 == Integer.MIN_VALUE) {
        }
        super.onMeasure(i3, i2);
        mode2 = getMeasuredWidth();
        i3 = MeasureSpec.makeMeasureSpec(mode2, 1073741824);
        if (obj3 == null) {
        }
        if (typedValue.type != 5) {
        }
        i = (int) dimension;
        if (i > 0) {
        }
        if (mode2 < i) {
        }
        obj2 = null;
        if (obj2 != null) {
        }
    }

    public TypedValue getMinWidthMajor() {
        if (this.mMinWidthMajor == null) {
            this.mMinWidthMajor = new TypedValue();
        }
        return this.mMinWidthMajor;
    }

    public TypedValue getMinWidthMinor() {
        if (this.mMinWidthMinor == null) {
            this.mMinWidthMinor = new TypedValue();
        }
        return this.mMinWidthMinor;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.mFixedWidthMajor == null) {
            this.mFixedWidthMajor = new TypedValue();
        }
        return this.mFixedWidthMajor;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.mFixedWidthMinor == null) {
            this.mFixedWidthMinor = new TypedValue();
        }
        return this.mFixedWidthMinor;
    }

    public TypedValue getFixedHeightMajor() {
        if (this.mFixedHeightMajor == null) {
            this.mFixedHeightMajor = new TypedValue();
        }
        return this.mFixedHeightMajor;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.mFixedHeightMinor == null) {
            this.mFixedHeightMinor = new TypedValue();
        }
        return this.mFixedHeightMinor;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        OnAttachListener onAttachListener = this.mAttachListener;
        if (onAttachListener != null) {
            onAttachListener.onAttachedFromWindow();
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        OnAttachListener onAttachListener = this.mAttachListener;
        if (onAttachListener != null) {
            onAttachListener.onDetachedFromWindow();
        }
    }
}
