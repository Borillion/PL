package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import androidx.annotation.RestrictTo;
import androidx.annotation.RestrictTo.Scope;
import androidx.appcompat.R;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class LinearLayoutCompat extends ViewGroup {
    public static final int HORIZONTAL = 0;
    private static final int INDEX_BOTTOM = 2;
    private static final int INDEX_CENTER_VERTICAL = 0;
    private static final int INDEX_FILL = 3;
    private static final int INDEX_TOP = 1;
    public static final int SHOW_DIVIDER_BEGINNING = 1;
    public static final int SHOW_DIVIDER_END = 4;
    public static final int SHOW_DIVIDER_MIDDLE = 2;
    public static final int SHOW_DIVIDER_NONE = 0;
    public static final int VERTICAL = 1;
    private static final int VERTICAL_GRAVITY_COUNT = 4;
    private boolean mBaselineAligned;
    private int mBaselineAlignedChildIndex;
    private int mBaselineChildTop;
    private Drawable mDivider;
    private int mDividerHeight;
    private int mDividerPadding;
    private int mDividerWidth;
    private int mGravity;
    private int[] mMaxAscent;
    private int[] mMaxDescent;
    private int mOrientation;
    private int mShowDividers;
    private int mTotalLength;
    private boolean mUseLargestChild;
    private float mWeightSum;

    @RestrictTo({Scope.LIBRARY_GROUP})
    @Retention(RetentionPolicy.SOURCE)
    public @interface DividerMode {
    }

    public static class LayoutParams extends MarginLayoutParams {
        public int gravity;
        public float weight;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.gravity = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.LinearLayoutCompat_Layout);
            this.weight = obtainStyledAttributes.getFloat(R.styleable.LinearLayoutCompat_Layout_android_layout_weight, 0.0f);
            this.gravity = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_Layout_android_layout_gravity, -1);
            obtainStyledAttributes.recycle();
        }

        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.gravity = -1;
            this.weight = 0.0f;
        }

        public LayoutParams(int i, int i2, float f) {
            super(i, i2);
            this.gravity = -1;
            this.weight = f;
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.gravity = -1;
        }

        public LayoutParams(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.gravity = -1;
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.gravity = -1;
            this.weight = layoutParams.weight;
            this.gravity = layoutParams.gravity;
        }
    }

    @RestrictTo({Scope.LIBRARY_GROUP})
    @Retention(RetentionPolicy.SOURCE)
    public @interface OrientationMode {
    }

    int getChildrenSkipCount(View view, int i) {
        return 0;
    }

    int getLocationOffset(View view) {
        return 0;
    }

    int getNextLocationOffset(View view) {
        return 0;
    }

    int measureNullChild(int i) {
        return 0;
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public LinearLayoutCompat(Context context) {
        this(context, null);
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mBaselineAligned = true;
        this.mBaselineAlignedChildIndex = -1;
        this.mBaselineChildTop = 0;
        this.mGravity = 8388659;
        TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, attributeSet, R.styleable.LinearLayoutCompat, i, 0);
        int i2 = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
        if (i2 >= 0) {
            setOrientation(i2);
        }
        i2 = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
        if (i2 >= 0) {
            setGravity(i2);
        }
        boolean z = obtainStyledAttributes.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
        if (!z) {
            setBaselineAligned(z);
        }
        this.mWeightSum = obtainStyledAttributes.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0f);
        this.mBaselineAlignedChildIndex = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
        this.mUseLargestChild = obtainStyledAttributes.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
        setDividerDrawable(obtainStyledAttributes.getDrawable(R.styleable.LinearLayoutCompat_divider));
        this.mShowDividers = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
        this.mDividerPadding = obtainStyledAttributes.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
        obtainStyledAttributes.recycle();
    }

    public void setShowDividers(int i) {
        if (i != this.mShowDividers) {
            requestLayout();
        }
        this.mShowDividers = i;
    }

    public int getShowDividers() {
        return this.mShowDividers;
    }

    public Drawable getDividerDrawable() {
        return this.mDivider;
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable != this.mDivider) {
            this.mDivider = drawable;
            boolean z = false;
            if (drawable != null) {
                this.mDividerWidth = drawable.getIntrinsicWidth();
                this.mDividerHeight = drawable.getIntrinsicHeight();
            } else {
                this.mDividerWidth = 0;
                this.mDividerHeight = 0;
            }
            if (drawable == null) {
                z = true;
            }
            setWillNotDraw(z);
            requestLayout();
        }
    }

    public void setDividerPadding(int i) {
        this.mDividerPadding = i;
    }

    public int getDividerPadding() {
        return this.mDividerPadding;
    }

    @RestrictTo({Scope.LIBRARY_GROUP})
    public int getDividerWidth() {
        return this.mDividerWidth;
    }

    protected void onDraw(Canvas canvas) {
        if (this.mDivider != null) {
            if (this.mOrientation == 1) {
                drawDividersVertical(canvas);
            } else {
                drawDividersHorizontal(canvas);
            }
        }
    }

    void drawDividersVertical(Canvas canvas) {
        int virtualChildCount = getVirtualChildCount();
        int i = 0;
        while (i < virtualChildCount) {
            View virtualChildAt = getVirtualChildAt(i);
            if (!(virtualChildAt == null || virtualChildAt.getVisibility() == 8 || !hasDividerBeforeChildAt(i))) {
                drawHorizontalDivider(canvas, (virtualChildAt.getTop() - ((LayoutParams) virtualChildAt.getLayoutParams()).topMargin) - this.mDividerHeight);
            }
            i++;
        }
        if (hasDividerBeforeChildAt(virtualChildCount)) {
            View virtualChildAt2 = getVirtualChildAt(virtualChildCount - 1);
            if (virtualChildAt2 == null) {
                virtualChildCount = (getHeight() - getPaddingBottom()) - this.mDividerHeight;
            } else {
                virtualChildCount = virtualChildAt2.getBottom() + ((LayoutParams) virtualChildAt2.getLayoutParams()).bottomMargin;
            }
            drawHorizontalDivider(canvas, virtualChildCount);
        }
    }

    void drawDividersHorizontal(Canvas canvas) {
        int virtualChildCount = getVirtualChildCount();
        boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
        int i = 0;
        while (i < virtualChildCount) {
            View virtualChildAt = getVirtualChildAt(i);
            if (!(virtualChildAt == null || virtualChildAt.getVisibility() == 8 || !hasDividerBeforeChildAt(i))) {
                int right;
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                if (isLayoutRtl) {
                    right = virtualChildAt.getRight() + layoutParams.rightMargin;
                } else {
                    right = (virtualChildAt.getLeft() - layoutParams.leftMargin) - this.mDividerWidth;
                }
                drawVerticalDivider(canvas, right);
            }
            i++;
        }
        if (hasDividerBeforeChildAt(virtualChildCount)) {
            int i2;
            View virtualChildAt2 = getVirtualChildAt(virtualChildCount - 1);
            if (virtualChildAt2 != null) {
                LayoutParams layoutParams2 = (LayoutParams) virtualChildAt2.getLayoutParams();
                if (isLayoutRtl) {
                    virtualChildCount = virtualChildAt2.getLeft() - layoutParams2.leftMargin;
                    i2 = this.mDividerWidth;
                } else {
                    virtualChildCount = virtualChildAt2.getRight() + layoutParams2.rightMargin;
                    drawVerticalDivider(canvas, virtualChildCount);
                }
            } else if (isLayoutRtl) {
                virtualChildCount = getPaddingLeft();
                drawVerticalDivider(canvas, virtualChildCount);
            } else {
                virtualChildCount = getWidth() - getPaddingRight();
                i2 = this.mDividerWidth;
            }
            virtualChildCount -= i2;
            drawVerticalDivider(canvas, virtualChildCount);
        }
    }

    void drawHorizontalDivider(Canvas canvas, int i) {
        this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, i, (getWidth() - getPaddingRight()) - this.mDividerPadding, this.mDividerHeight + i);
        this.mDivider.draw(canvas);
    }

    void drawVerticalDivider(Canvas canvas, int i) {
        this.mDivider.setBounds(i, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + i, (getHeight() - getPaddingBottom()) - this.mDividerPadding);
        this.mDivider.draw(canvas);
    }

    public boolean isBaselineAligned() {
        return this.mBaselineAligned;
    }

    public void setBaselineAligned(boolean z) {
        this.mBaselineAligned = z;
    }

    public boolean isMeasureWithLargestChildEnabled() {
        return this.mUseLargestChild;
    }

    public void setMeasureWithLargestChildEnabled(boolean z) {
        this.mUseLargestChild = z;
    }

    public int getBaseline() {
        if (this.mBaselineAlignedChildIndex < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i = this.mBaselineAlignedChildIndex;
        if (childCount > i) {
            View childAt = getChildAt(i);
            i = childAt.getBaseline();
            if (i != -1) {
                int i2 = this.mBaselineChildTop;
                if (this.mOrientation == 1) {
                    int i3 = this.mGravity & 112;
                    if (i3 != 48) {
                        if (i3 == 16) {
                            i2 += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.mTotalLength) / 2;
                        } else if (i3 == 80) {
                            i2 = ((getBottom() - getTop()) - getPaddingBottom()) - this.mTotalLength;
                        }
                    }
                }
                return (i2 + ((LayoutParams) childAt.getLayoutParams()).topMargin) + i;
            } else if (this.mBaselineAlignedChildIndex == 0) {
                return -1;
            } else {
                throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
        }
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
    }

    public int getBaselineAlignedChildIndex() {
        return this.mBaselineAlignedChildIndex;
    }

    public void setBaselineAlignedChildIndex(int i) {
        if (i < 0 || i >= getChildCount()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("base aligned child index out of range (0, ");
            stringBuilder.append(getChildCount());
            stringBuilder.append(")");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        this.mBaselineAlignedChildIndex = i;
    }

    View getVirtualChildAt(int i) {
        return getChildAt(i);
    }

    int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.mWeightSum;
    }

    public void setWeightSum(float f) {
        this.mWeightSum = Math.max(0.0f, f);
    }

    protected void onMeasure(int i, int i2) {
        if (this.mOrientation == 1) {
            measureVertical(i, i2);
        } else {
            measureHorizontal(i, i2);
        }
    }

    @RestrictTo({Scope.LIBRARY})
    protected boolean hasDividerBeforeChildAt(int i) {
        boolean z = false;
        if (i == 0) {
            if ((this.mShowDividers & 1) != 0) {
                z = true;
            }
            return z;
        } else if (i == getChildCount()) {
            if ((this.mShowDividers & 4) != 0) {
                z = true;
            }
            return z;
        } else {
            if ((this.mShowDividers & 2) != 0) {
                for (i--; i >= 0; i--) {
                    if (getChildAt(i).getVisibility() != 8) {
                        z = true;
                        break;
                    }
                }
            }
            return z;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:141:0x0335  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    void measureVertical(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        this.mTotalLength = 0;
        int virtualChildCount = getVirtualChildCount();
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        int i5 = this.mBaselineAlignedChildIndex;
        boolean z = this.mUseLargestChild;
        int i6 = 0;
        int i7 = i6;
        int i8 = i7;
        int i9 = i8;
        int i10 = i9;
        int i11 = i10;
        int i12 = i11;
        int i13 = i12;
        float f = 0.0f;
        Object obj = 1;
        while (true) {
            int i14 = 8;
            int i15 = i9;
            int i16;
            int i17;
            View view;
            int i18;
            if (i11 < virtualChildCount) {
                View virtualChildAt = getVirtualChildAt(i11);
                if (virtualChildAt == null) {
                    this.mTotalLength += measureNullChild(i11);
                    i16 = virtualChildCount;
                    i9 = i15;
                } else {
                    int i19 = i6;
                    if (virtualChildAt.getVisibility() == 8) {
                        i11 += getChildrenSkipCount(virtualChildAt, i11);
                        i16 = virtualChildCount;
                        i9 = i15;
                        i6 = i19;
                    } else {
                        int i20;
                        int i21;
                        if (hasDividerBeforeChildAt(i11)) {
                            this.mTotalLength += this.mDividerHeight;
                        }
                        LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                        float f2 = f + layoutParams.weight;
                        int i22;
                        if (mode2 == 1073741824 && layoutParams.height == 0 && layoutParams.weight > 0.0f) {
                            i17 = this.mTotalLength;
                            i22 = i7;
                            this.mTotalLength = Math.max(i17, (layoutParams.topMargin + i17) + layoutParams.bottomMargin);
                            i17 = i8;
                            view = virtualChildAt;
                            i20 = i10;
                            i16 = virtualChildCount;
                            i12 = 1;
                            i3 = i19;
                            i21 = i22;
                            virtualChildCount = i11;
                            i18 = i15;
                            i15 = mode2;
                            mode2 = i18;
                        } else {
                            i22 = i7;
                            if (layoutParams.height != 0 || layoutParams.weight <= 0.0f) {
                                i7 = Integer.MIN_VALUE;
                            } else {
                                layoutParams.height = -2;
                                i7 = 0;
                            }
                            i3 = i19;
                            int i23 = i7;
                            i21 = i22;
                            i4 = i8;
                            View view2 = virtualChildAt;
                            i16 = virtualChildCount;
                            virtualChildCount = 1073741824;
                            int i24 = i15;
                            i15 = mode2;
                            mode2 = i24;
                            i20 = i10;
                            virtualChildCount = i11;
                            measureChildBeforeLayout(virtualChildAt, i11, i, 0, i2, f2 == 0.0f ? this.mTotalLength : 0);
                            i17 = i23;
                            if (i17 != Integer.MIN_VALUE) {
                                layoutParams.height = i17;
                            }
                            i17 = view2.getMeasuredHeight();
                            i6 = this.mTotalLength;
                            view = view2;
                            this.mTotalLength = Math.max(i6, (((i6 + i17) + layoutParams.topMargin) + layoutParams.bottomMargin) + getNextLocationOffset(view));
                            i17 = z ? Math.max(i17, i4) : i4;
                        }
                        if (i5 >= 0 && i5 == virtualChildCount + 1) {
                            this.mBaselineChildTop = this.mTotalLength;
                        }
                        if (virtualChildCount >= i5 || layoutParams.weight <= 0.0f) {
                            if (mode == 1073741824 || layoutParams.width != -1) {
                                i6 = 0;
                            } else {
                                i6 = 1;
                                i13 = i6;
                            }
                            i7 = layoutParams.leftMargin + layoutParams.rightMargin;
                            i9 = view.getMeasuredWidth() + i7;
                            i10 = Math.max(i21, i9);
                            i11 = View.combineMeasuredStates(i3, view.getMeasuredState());
                            Object obj2 = (obj == null || layoutParams.width != -1) ? null : 1;
                            if (layoutParams.weight > 0.0f) {
                                if (i6 == 0) {
                                    i7 = i9;
                                }
                                mode2 = Math.max(mode2, i7);
                                i6 = i20;
                            } else {
                                if (i6 == 0) {
                                    i7 = i9;
                                }
                                i6 = Math.max(i20, i7);
                            }
                            i8 = i17;
                            obj = obj2;
                            i9 = mode2;
                            f = f2;
                            i18 = i10;
                            i10 = i6;
                            i6 = i11;
                            i11 = getChildrenSkipCount(view, virtualChildCount) + virtualChildCount;
                            i7 = i18;
                            i11++;
                            i3 = i;
                            i4 = i2;
                            mode2 = i15;
                            virtualChildCount = i16;
                        } else {
                            throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
                        }
                    }
                }
                i15 = mode2;
                i11++;
                i3 = i;
                i4 = i2;
                mode2 = i15;
                virtualChildCount = i16;
            } else {
                i3 = i6;
                i4 = i8;
                i6 = i10;
                i16 = virtualChildCount;
                i10 = i7;
                i18 = i15;
                i15 = mode2;
                mode2 = i18;
                if (this.mTotalLength > 0) {
                    i7 = i16;
                    if (hasDividerBeforeChildAt(i7)) {
                        this.mTotalLength += this.mDividerHeight;
                    }
                } else {
                    i7 = i16;
                }
                if (z) {
                    i8 = i15;
                    if (i8 == Integer.MIN_VALUE || i8 == 0) {
                        this.mTotalLength = 0;
                        i9 = 0;
                        while (i9 < i7) {
                            View virtualChildAt2 = getVirtualChildAt(i9);
                            if (virtualChildAt2 == null) {
                                this.mTotalLength += measureNullChild(i9);
                            } else if (virtualChildAt2.getVisibility() == i14) {
                                i9 += getChildrenSkipCount(virtualChildAt2, i9);
                            } else {
                                LayoutParams layoutParams2 = (LayoutParams) virtualChildAt2.getLayoutParams();
                                i5 = this.mTotalLength;
                                this.mTotalLength = Math.max(i5, (((i5 + i4) + layoutParams2.topMargin) + layoutParams2.bottomMargin) + getNextLocationOffset(virtualChildAt2));
                            }
                            i9++;
                            i14 = 8;
                        }
                    }
                } else {
                    i8 = i15;
                }
                this.mTotalLength += getPaddingTop() + getPaddingBottom();
                i11 = i2;
                i14 = i4;
                i9 = View.resolveSizeAndState(Math.max(this.mTotalLength, getSuggestedMinimumHeight()), i11, 0);
                i4 = (16777215 & i9) - this.mTotalLength;
                if (i12 != 0 || (i4 != 0 && f > 0.0f)) {
                    float f3 = this.mWeightSum;
                    if (f3 > 0.0f) {
                        f = f3;
                    }
                    this.mTotalLength = 0;
                    float f4 = f;
                    i17 = 0;
                    i18 = i3;
                    i3 = i6;
                    i6 = i18;
                    while (i17 < i7) {
                        float f5;
                        View virtualChildAt3 = getVirtualChildAt(i17);
                        if (virtualChildAt3.getVisibility() == 8) {
                            f5 = f4;
                            virtualChildCount = i;
                        } else {
                            Object obj3;
                            Object obj4;
                            LayoutParams layoutParams3 = (LayoutParams) virtualChildAt3.getLayoutParams();
                            f3 = layoutParams3.weight;
                            if (f3 > 0.0f) {
                                int i25 = (int) ((((float) i4) * f3) / f4);
                                i12 = i4 - i25;
                                f5 = f4 - f3;
                                i4 = getChildMeasureSpec(i, ((getPaddingLeft() + getPaddingRight()) + layoutParams3.leftMargin) + layoutParams3.rightMargin, layoutParams3.width);
                                if (layoutParams3.height == 0) {
                                    i14 = 1073741824;
                                    if (i8 == 1073741824) {
                                        if (i25 <= 0) {
                                            i25 = 0;
                                        }
                                        virtualChildAt3.measure(i4, MeasureSpec.makeMeasureSpec(i25, 1073741824));
                                        i6 = View.combineMeasuredStates(i6, virtualChildAt3.getMeasuredState() & -256);
                                    }
                                } else {
                                    i14 = 1073741824;
                                }
                                i25 = virtualChildAt3.getMeasuredHeight() + i25;
                                if (i25 < 0) {
                                    i25 = 0;
                                }
                                virtualChildAt3.measure(i4, MeasureSpec.makeMeasureSpec(i25, i14));
                                i6 = View.combineMeasuredStates(i6, virtualChildAt3.getMeasuredState() & -256);
                            } else {
                                f3 = f4;
                                virtualChildCount = i;
                                i12 = i4;
                                f5 = f3;
                            }
                            i4 = layoutParams3.leftMargin + layoutParams3.rightMargin;
                            i14 = virtualChildAt3.getMeasuredWidth() + i4;
                            i10 = Math.max(i10, i14);
                            if (mode != 1073741824) {
                                i16 = i6;
                                i6 = -1;
                                if (layoutParams3.width == -1) {
                                    obj3 = 1;
                                    if (obj3 == null) {
                                        i4 = i14;
                                    }
                                    i3 = Math.max(i3, i4);
                                    obj4 = (obj == null && layoutParams3.width == i6) ? 1 : null;
                                    i14 = this.mTotalLength;
                                    this.mTotalLength = Math.max(i14, (((virtualChildAt3.getMeasuredHeight() + i14) + layoutParams3.topMargin) + layoutParams3.bottomMargin) + getNextLocationOffset(virtualChildAt3));
                                    obj = obj4;
                                    i4 = i12;
                                    i6 = i16;
                                }
                            } else {
                                i16 = i6;
                                i6 = -1;
                            }
                            obj3 = null;
                            if (obj3 == null) {
                            }
                            i3 = Math.max(i3, i4);
                            if (obj == null) {
                            }
                            i14 = this.mTotalLength;
                            this.mTotalLength = Math.max(i14, (((virtualChildAt3.getMeasuredHeight() + i14) + layoutParams3.topMargin) + layoutParams3.bottomMargin) + getNextLocationOffset(virtualChildAt3));
                            obj = obj4;
                            i4 = i12;
                            i6 = i16;
                        }
                        i17++;
                        f4 = f5;
                    }
                    virtualChildCount = i;
                    this.mTotalLength += getPaddingTop() + getPaddingBottom();
                    i17 = i3;
                } else {
                    i17 = Math.max(i6, mode2);
                    if (z && i8 != 1073741824) {
                        for (i6 = 0; i6 < i7; i6++) {
                            view = getVirtualChildAt(i6);
                            if (!(view == null || view.getVisibility() == 8 || ((LayoutParams) view.getLayoutParams()).weight <= 0.0f)) {
                                view.measure(MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), MeasureSpec.makeMeasureSpec(i14, 1073741824));
                            }
                        }
                    }
                    virtualChildCount = i;
                    i6 = i3;
                }
                if (obj != null || mode == 1073741824) {
                    i17 = i10;
                }
                setMeasuredDimension(View.resolveSizeAndState(Math.max(i17 + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), virtualChildCount, i6), i9);
                if (i13 != 0) {
                    forceUniformWidth(i7, i11);
                    return;
                }
                return;
            }
        }
    }

    private void forceUniformWidth(int i, int i2) {
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        for (int i3 = 0; i3 < i; i3++) {
            View virtualChildAt = getVirtualChildAt(i3);
            if (virtualChildAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                if (layoutParams.width == -1) {
                    int i4 = layoutParams.height;
                    layoutParams.height = virtualChildAt.getMeasuredHeight();
                    measureChildWithMargins(virtualChildAt, makeMeasureSpec, 0, i2, 0);
                    layoutParams.height = i4;
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:61:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x01db  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x01d0  */
    /* JADX WARNING: Removed duplicated region for block: B:183:0x044f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    void measureHorizontal(int i, int i2) {
        int[] iArr;
        int i3;
        boolean z;
        boolean z2;
        View view;
        int measuredHeight;
        int combineMeasuredStates;
        int baseline;
        int i4;
        int i5;
        LayoutParams layoutParams;
        int i6 = i;
        int i7 = i2;
        this.mTotalLength = 0;
        int virtualChildCount = getVirtualChildCount();
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        if (this.mMaxAscent == null || this.mMaxDescent == null) {
            this.mMaxAscent = new int[4];
            this.mMaxDescent = new int[4];
        }
        int[] iArr2 = this.mMaxAscent;
        int[] iArr3 = this.mMaxDescent;
        iArr2[3] = -1;
        iArr2[2] = -1;
        iArr2[1] = -1;
        iArr2[0] = -1;
        iArr3[3] = -1;
        iArr3[2] = -1;
        iArr3[1] = -1;
        iArr3[0] = -1;
        boolean z3 = this.mBaselineAligned;
        boolean z4 = this.mUseLargestChild;
        int i8 = 1073741824;
        int i9 = mode == 1073741824 ? 1 : 0;
        int i10 = 0;
        int i11 = i10;
        int i12 = i11;
        int i13 = i12;
        int i14 = i13;
        int i15 = i14;
        int i16 = i15;
        int i17 = i16;
        int i18 = 1;
        float f = 0.0f;
        while (true) {
            iArr = iArr3;
            if (i10 >= virtualChildCount) {
                break;
            }
            View virtualChildAt = getVirtualChildAt(i10);
            if (virtualChildAt == null) {
                this.mTotalLength += measureNullChild(i10);
            } else if (virtualChildAt.getVisibility() == 8) {
                i10 += getChildrenSkipCount(virtualChildAt, i10);
            } else {
                int i19;
                if (hasDividerBeforeChildAt(i10)) {
                    this.mTotalLength += this.mDividerWidth;
                }
                LayoutParams layoutParams2 = (LayoutParams) virtualChildAt.getLayoutParams();
                float f2 = f + layoutParams2.weight;
                if (mode == i8 && layoutParams2.width == 0 && layoutParams2.weight > 0.0f) {
                    if (i9 != 0) {
                        this.mTotalLength += layoutParams2.leftMargin + layoutParams2.rightMargin;
                    } else {
                        i3 = this.mTotalLength;
                        this.mTotalLength = Math.max(i3, (layoutParams2.leftMargin + i3) + layoutParams2.rightMargin);
                    }
                    if (z3) {
                        i8 = MeasureSpec.makeMeasureSpec(0, 0);
                        virtualChildAt.measure(i8, i8);
                        i19 = i10;
                        z = z4;
                        z2 = z3;
                        view = virtualChildAt;
                    } else {
                        i19 = i10;
                        z = z4;
                        z2 = z3;
                        view = virtualChildAt;
                        i15 = 1;
                        i10 = 1073741824;
                        if (mode2 == i10 && layoutParams2.height == -1) {
                            i3 = 1;
                            i17 = i3;
                        } else {
                            i3 = 0;
                        }
                        i8 = layoutParams2.topMargin + layoutParams2.bottomMargin;
                        measuredHeight = view.getMeasuredHeight() + i8;
                        combineMeasuredStates = View.combineMeasuredStates(i16, view.getMeasuredState());
                        if (z2) {
                            baseline = view.getBaseline();
                            if (baseline != -1) {
                                i7 = ((((layoutParams2.gravity < 0 ? this.mGravity : layoutParams2.gravity) & 112) >> 4) & -2) >> 1;
                                iArr2[i7] = Math.max(iArr2[i7], baseline);
                                iArr[i7] = Math.max(iArr[i7], measuredHeight - baseline);
                            }
                        }
                        i10 = Math.max(i12, measuredHeight);
                        baseline = (i18 == 0 && layoutParams2.height == -1) ? 1 : 0;
                        if (layoutParams2.weight <= 0.0f) {
                            if (i3 == 0) {
                                i8 = measuredHeight;
                            }
                            i14 = Math.max(i14, i8);
                        } else {
                            i4 = i14;
                            if (i3 != 0) {
                                measuredHeight = i8;
                            }
                            i13 = Math.max(i13, measuredHeight);
                            i14 = i4;
                        }
                        i4 = i19;
                        i12 = i10;
                        i16 = combineMeasuredStates;
                        i18 = baseline;
                        i10 = getChildrenSkipCount(view, i4) + i4;
                        f = f2;
                        i10++;
                        i7 = i2;
                        iArr3 = iArr;
                        z4 = z;
                        z3 = z2;
                        i8 = 1073741824;
                    }
                } else {
                    if (layoutParams2.width != 0 || layoutParams2.weight <= 0.0f) {
                        combineMeasuredStates = -2;
                        i8 = Integer.MIN_VALUE;
                    } else {
                        combineMeasuredStates = -2;
                        layoutParams2.width = -2;
                        i8 = 0;
                    }
                    i19 = i10;
                    int i20 = i8;
                    z = z4;
                    z2 = z3;
                    int i21 = combineMeasuredStates;
                    View view2 = virtualChildAt;
                    measureChildBeforeLayout(virtualChildAt, i19, i, f2 == 0.0f ? this.mTotalLength : 0, i2, 0);
                    i3 = i20;
                    if (i3 != Integer.MIN_VALUE) {
                        layoutParams2.width = i3;
                    }
                    i3 = view2.getMeasuredWidth();
                    if (i9 != 0) {
                        view = view2;
                        this.mTotalLength += ((layoutParams2.leftMargin + i3) + layoutParams2.rightMargin) + getNextLocationOffset(view);
                    } else {
                        view = view2;
                        i10 = this.mTotalLength;
                        this.mTotalLength = Math.max(i10, (((i10 + i3) + layoutParams2.leftMargin) + layoutParams2.rightMargin) + getNextLocationOffset(view));
                    }
                    if (z) {
                        i11 = Math.max(i3, i11);
                    }
                }
                i10 = 1073741824;
                if (mode2 == i10) {
                }
                i3 = 0;
                i8 = layoutParams2.topMargin + layoutParams2.bottomMargin;
                measuredHeight = view.getMeasuredHeight() + i8;
                combineMeasuredStates = View.combineMeasuredStates(i16, view.getMeasuredState());
                if (z2) {
                }
                i10 = Math.max(i12, measuredHeight);
                if (i18 == 0) {
                }
                if (layoutParams2.weight <= 0.0f) {
                }
                i4 = i19;
                i12 = i10;
                i16 = combineMeasuredStates;
                i18 = baseline;
                i10 = getChildrenSkipCount(view, i4) + i4;
                f = f2;
                i10++;
                i7 = i2;
                iArr3 = iArr;
                z4 = z;
                z3 = z2;
                i8 = 1073741824;
            }
            z = z4;
            z2 = z3;
            i10++;
            i7 = i2;
            iArr3 = iArr;
            z4 = z;
            z3 = z2;
            i8 = 1073741824;
        }
        z = z4;
        z2 = z3;
        i10 = i12;
        i8 = i13;
        i4 = i14;
        baseline = i16;
        if (this.mTotalLength > 0 && hasDividerBeforeChildAt(virtualChildCount)) {
            this.mTotalLength += this.mDividerWidth;
        }
        if (iArr2[1] == -1 && iArr2[0] == -1 && iArr2[2] == -1 && iArr2[3] == -1) {
            i14 = baseline;
        } else {
            i14 = baseline;
            i10 = Math.max(i10, Math.max(iArr2[3], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))) + Math.max(iArr[3], Math.max(iArr[0], Math.max(iArr[1], iArr[2]))));
        }
        if (z && (mode == Integer.MIN_VALUE || mode == 0)) {
            this.mTotalLength = 0;
            i5 = 0;
            while (i5 < virtualChildCount) {
                View virtualChildAt2 = getVirtualChildAt(i5);
                if (virtualChildAt2 == null) {
                    this.mTotalLength += measureNullChild(i5);
                } else if (virtualChildAt2.getVisibility() == 8) {
                    i5 += getChildrenSkipCount(virtualChildAt2, i5);
                } else {
                    layoutParams = (LayoutParams) virtualChildAt2.getLayoutParams();
                    if (i9 != 0) {
                        this.mTotalLength += ((layoutParams.leftMargin + i11) + layoutParams.rightMargin) + getNextLocationOffset(virtualChildAt2);
                    } else {
                        baseline = this.mTotalLength;
                        i13 = i10;
                        this.mTotalLength = Math.max(baseline, (((baseline + i11) + layoutParams.leftMargin) + layoutParams.rightMargin) + getNextLocationOffset(virtualChildAt2));
                        i5++;
                        i10 = i13;
                    }
                }
                i13 = i10;
                i5++;
                i10 = i13;
            }
        }
        i13 = i10;
        this.mTotalLength += getPaddingLeft() + getPaddingRight();
        i10 = View.resolveSizeAndState(Math.max(this.mTotalLength, getSuggestedMinimumWidth()), i6, 0);
        i5 = (16777215 & i10) - this.mTotalLength;
        if (i15 != 0 || (i5 != 0 && f > 0.0f)) {
            float f3 = this.mWeightSum;
            if (f3 > 0.0f) {
                f = f3;
            }
            iArr2[3] = -1;
            iArr2[2] = -1;
            iArr2[1] = -1;
            iArr2[0] = -1;
            iArr[3] = -1;
            iArr[2] = -1;
            iArr[1] = -1;
            iArr[0] = -1;
            this.mTotalLength = 0;
            i4 = i8;
            baseline = -1;
            i7 = i14;
            float f4 = f;
            i3 = 0;
            while (i3 < virtualChildCount) {
                View virtualChildAt3 = getVirtualChildAt(i3);
                if (virtualChildAt3 == null || virtualChildAt3.getVisibility() == 8) {
                    measuredHeight = i5;
                    i16 = virtualChildCount;
                    i5 = i2;
                } else {
                    float f5;
                    layoutParams = (LayoutParams) virtualChildAt3.getLayoutParams();
                    float f6 = layoutParams.weight;
                    if (f6 > 0.0f) {
                        i6 = (int) ((((float) i5) * f6) / f4);
                        f5 = f4 - f6;
                        i15 = i5 - i6;
                        i16 = virtualChildCount;
                        i8 = getChildMeasureSpec(i2, ((getPaddingTop() + getPaddingBottom()) + layoutParams.topMargin) + layoutParams.bottomMargin, layoutParams.height);
                        if (layoutParams.width == 0) {
                            measuredHeight = 1073741824;
                            if (mode == 1073741824) {
                                if (i6 <= 0) {
                                    i6 = 0;
                                }
                                virtualChildAt3.measure(MeasureSpec.makeMeasureSpec(i6, 1073741824), i8);
                                i7 = View.combineMeasuredStates(i7, virtualChildAt3.getMeasuredState() & -16777216);
                                f4 = f5;
                                measuredHeight = i15;
                            }
                        } else {
                            measuredHeight = 1073741824;
                        }
                        i6 = virtualChildAt3.getMeasuredWidth() + i6;
                        if (i6 < 0) {
                            i6 = 0;
                        }
                        virtualChildAt3.measure(MeasureSpec.makeMeasureSpec(i6, measuredHeight), i8);
                        i7 = View.combineMeasuredStates(i7, virtualChildAt3.getMeasuredState() & -16777216);
                        f4 = f5;
                        measuredHeight = i15;
                    } else {
                        measuredHeight = i5;
                        i16 = virtualChildCount;
                        i5 = i2;
                    }
                    if (i9 != 0) {
                        this.mTotalLength += ((virtualChildAt3.getMeasuredWidth() + layoutParams.leftMargin) + layoutParams.rightMargin) + getNextLocationOffset(virtualChildAt3);
                        f5 = f4;
                    } else {
                        i6 = this.mTotalLength;
                        f5 = f4;
                        this.mTotalLength = Math.max(i6, (((virtualChildAt3.getMeasuredWidth() + i6) + layoutParams.leftMargin) + layoutParams.rightMargin) + getNextLocationOffset(virtualChildAt3));
                    }
                    i8 = (mode2 == 1073741824 || layoutParams.height != -1) ? 0 : 1;
                    i6 = layoutParams.topMargin + layoutParams.bottomMargin;
                    virtualChildCount = virtualChildAt3.getMeasuredHeight() + i6;
                    baseline = Math.max(baseline, virtualChildCount);
                    if (i8 == 0) {
                        i6 = virtualChildCount;
                    }
                    i8 = Math.max(i4, i6);
                    if (i18 != 0) {
                        i4 = -1;
                        if (layoutParams.height == -1) {
                            i6 = 1;
                            if (z2) {
                                i11 = virtualChildAt3.getBaseline();
                                if (i11 != i4) {
                                    combineMeasuredStates = ((((layoutParams.gravity < 0 ? this.mGravity : layoutParams.gravity) & 112) >> 4) & -2) >> 1;
                                    iArr2[combineMeasuredStates] = Math.max(iArr2[combineMeasuredStates], i11);
                                    iArr[combineMeasuredStates] = Math.max(iArr[combineMeasuredStates], virtualChildCount - i11);
                                    i4 = i8;
                                    i18 = i6;
                                    f4 = f5;
                                }
                            }
                            i4 = i8;
                            i18 = i6;
                            f4 = f5;
                        }
                    } else {
                        i4 = -1;
                    }
                    i6 = 0;
                    if (z2) {
                    }
                    i4 = i8;
                    i18 = i6;
                    f4 = f5;
                }
                i3++;
                i6 = i;
                i5 = measuredHeight;
                virtualChildCount = i16;
            }
            i5 = i2;
            i16 = virtualChildCount;
            this.mTotalLength += getPaddingLeft() + getPaddingRight();
            if (iArr2[1] == -1 && iArr2[0] == -1 && iArr2[2] == -1 && iArr2[3] == -1) {
                i3 = baseline;
            } else {
                i3 = Math.max(baseline, Math.max(iArr2[3], Math.max(iArr2[0], Math.max(iArr2[1], iArr2[2]))) + Math.max(iArr[3], Math.max(iArr[0], Math.max(iArr[1], iArr[2]))));
            }
            i8 = i3;
            i14 = i7;
            i3 = i4;
        } else {
            i3 = Math.max(i8, i4);
            if (z && mode != 1073741824) {
                for (i8 = 0; i8 < virtualChildCount; i8++) {
                    view = getVirtualChildAt(i8);
                    if (!(view == null || view.getVisibility() == 8 || ((LayoutParams) view.getLayoutParams()).weight <= 0.0f)) {
                        view.measure(MeasureSpec.makeMeasureSpec(i11, 1073741824), MeasureSpec.makeMeasureSpec(view.getMeasuredHeight(), 1073741824));
                    }
                }
            }
            i5 = i2;
            i16 = virtualChildCount;
            i8 = i13;
        }
        if (i18 != 0 || mode2 == 1073741824) {
            i3 = i8;
        }
        setMeasuredDimension(i10 | (i14 & -16777216), View.resolveSizeAndState(Math.max(i3 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), i5, i14 << 16));
        if (i17 != 0) {
            forceUniformHeight(i16, i);
        }
    }

    private void forceUniformHeight(int i, int i2) {
        int makeMeasureSpec = MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        for (int i3 = 0; i3 < i; i3++) {
            View virtualChildAt = getVirtualChildAt(i3);
            if (virtualChildAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                if (layoutParams.height == -1) {
                    int i4 = layoutParams.width;
                    layoutParams.width = virtualChildAt.getMeasuredWidth();
                    measureChildWithMargins(virtualChildAt, i2, 0, makeMeasureSpec, 0);
                    layoutParams.width = i4;
                }
            }
        }
    }

    void measureChildBeforeLayout(View view, int i, int i2, int i3, int i4, int i5) {
        measureChildWithMargins(view, i2, i3, i4, i5);
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.mOrientation == 1) {
            layoutVertical(i, i2, i3, i4);
        } else {
            layoutHorizontal(i, i2, i3, i4);
        }
    }

    void layoutVertical(int i, int i2, int i3, int i4) {
        int paddingLeft = getPaddingLeft();
        int i5 = i3 - i;
        int paddingRight = i5 - getPaddingRight();
        int paddingRight2 = (i5 - paddingLeft) - getPaddingRight();
        int virtualChildCount = getVirtualChildCount();
        i5 = this.mGravity;
        int i6 = i5 & 112;
        int i7 = i5 & 8388615;
        if (i6 == 16) {
            i5 = getPaddingTop() + (((i4 - i2) - this.mTotalLength) / 2);
        } else if (i6 != 80) {
            i5 = getPaddingTop();
        } else {
            i5 = ((getPaddingTop() + i4) - i2) - this.mTotalLength;
        }
        int i8 = 0;
        while (i8 < virtualChildCount) {
            View virtualChildAt = getVirtualChildAt(i8);
            if (virtualChildAt == null) {
                i5 += measureNullChild(i8);
            } else if (virtualChildAt.getVisibility() != 8) {
                int i9;
                int measuredWidth = virtualChildAt.getMeasuredWidth();
                int measuredHeight = virtualChildAt.getMeasuredHeight();
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                i6 = layoutParams.gravity;
                if (i6 < 0) {
                    i6 = i7;
                }
                i6 = GravityCompat.getAbsoluteGravity(i6, ViewCompat.getLayoutDirection(this)) & 7;
                if (i6 == 1) {
                    i6 = (((paddingRight2 - measuredWidth) / 2) + paddingLeft) + layoutParams.leftMargin;
                    i9 = layoutParams.rightMargin;
                    i6 -= i9;
                } else if (i6 != 5) {
                    i6 = layoutParams.leftMargin + paddingLeft;
                } else {
                    i6 = paddingRight - measuredWidth;
                    i9 = layoutParams.rightMargin;
                    i6 -= i9;
                }
                i9 = i6;
                if (hasDividerBeforeChildAt(i8)) {
                    i5 += this.mDividerHeight;
                }
                int i10 = i5 + layoutParams.topMargin;
                LayoutParams layoutParams2 = layoutParams;
                setChildFrame(virtualChildAt, i9, i10 + getLocationOffset(virtualChildAt), measuredWidth, measuredHeight);
                i8 += getChildrenSkipCount(virtualChildAt, i8);
                i5 = i10 + ((measuredHeight + layoutParams2.bottomMargin) + getNextLocationOffset(virtualChildAt));
                i6 = 1;
                i8 += i6;
            }
            i6 = 1;
            i8 += i6;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x00b1  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00f1  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00ba  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0105  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    void layoutHorizontal(int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
        int paddingTop = getPaddingTop();
        int i7 = i4 - i2;
        int paddingBottom = i7 - getPaddingBottom();
        int paddingBottom2 = (i7 - paddingTop) - getPaddingBottom();
        int virtualChildCount = getVirtualChildCount();
        i7 = this.mGravity;
        int i8 = 8388615 & i7;
        int i9 = i7 & 112;
        boolean z = this.mBaselineAligned;
        int[] iArr = this.mMaxAscent;
        int[] iArr2 = this.mMaxDescent;
        i7 = GravityCompat.getAbsoluteGravity(i8, ViewCompat.getLayoutDirection(this));
        int i10 = 1;
        if (i7 == 1) {
            i7 = getPaddingLeft() + (((i3 - i) - this.mTotalLength) / 2);
        } else if (i7 != 5) {
            i7 = getPaddingLeft();
        } else {
            i7 = ((getPaddingLeft() + i3) - i) - this.mTotalLength;
        }
        if (isLayoutRtl) {
            i5 = virtualChildCount - 1;
            i6 = -1;
        } else {
            i5 = 0;
            i6 = 1;
        }
        int i11 = 0;
        while (i11 < virtualChildCount) {
            int i12;
            int i13;
            int i14;
            int i15;
            i8 = i5 + (i6 * i11);
            View virtualChildAt = getVirtualChildAt(i8);
            int i16;
            if (virtualChildAt == null) {
                i7 += measureNullChild(i8);
                i12 = i10;
                i13 = paddingTop;
                i14 = virtualChildCount;
                i15 = i9;
            } else if (virtualChildAt.getVisibility() != 8) {
                View view;
                View view2;
                LayoutParams layoutParams;
                int measuredWidth = virtualChildAt.getMeasuredWidth();
                i10 = virtualChildAt.getMeasuredHeight();
                LayoutParams layoutParams2 = (LayoutParams) virtualChildAt.getLayoutParams();
                if (z) {
                    i16 = i11;
                    i14 = virtualChildCount;
                    if (layoutParams2.height != -1) {
                        i11 = virtualChildAt.getBaseline();
                        virtualChildCount = layoutParams2.gravity;
                        if (virtualChildCount < 0) {
                            virtualChildCount = i9;
                        }
                        virtualChildCount &= 112;
                        i15 = i9;
                        if (virtualChildCount != 16) {
                            i12 = 1;
                            i11 = ((((paddingBottom2 - i10) / 2) + paddingTop) + layoutParams2.topMargin) - layoutParams2.bottomMargin;
                        } else if (virtualChildCount != 48) {
                            if (virtualChildCount != 80) {
                                i11 = paddingTop;
                            } else {
                                virtualChildCount = (paddingBottom - i10) - layoutParams2.bottomMargin;
                                if (i11 != -1) {
                                    virtualChildCount -= iArr2[2] - (virtualChildAt.getMeasuredHeight() - i11);
                                }
                                i11 = virtualChildCount;
                            }
                            i12 = 1;
                        } else {
                            virtualChildCount = layoutParams2.topMargin + paddingTop;
                            if (i11 != -1) {
                                i12 = 1;
                                virtualChildCount += iArr[1] - i11;
                            } else {
                                i12 = 1;
                            }
                            i11 = virtualChildCount;
                        }
                        if (hasDividerBeforeChildAt(i8)) {
                            i7 += this.mDividerWidth;
                        }
                        virtualChildCount = layoutParams2.leftMargin + i7;
                        view = virtualChildAt;
                        view2 = view;
                        i9 = i8;
                        i8 = virtualChildCount + getLocationOffset(virtualChildAt);
                        i13 = paddingTop;
                        layoutParams = layoutParams2;
                        setChildFrame(view, i8, i11, measuredWidth, i10);
                        virtualChildAt = view2;
                        i11 = i16 + getChildrenSkipCount(virtualChildAt, i9);
                        i7 = virtualChildCount + ((measuredWidth + layoutParams.rightMargin) + getNextLocationOffset(virtualChildAt));
                        i11++;
                        virtualChildCount = i14;
                        i9 = i15;
                        i10 = i12;
                        paddingTop = i13;
                    }
                } else {
                    i16 = i11;
                    i14 = virtualChildCount;
                }
                i11 = -1;
                virtualChildCount = layoutParams2.gravity;
                if (virtualChildCount < 0) {
                }
                virtualChildCount &= 112;
                i15 = i9;
                if (virtualChildCount != 16) {
                }
                if (hasDividerBeforeChildAt(i8)) {
                }
                virtualChildCount = layoutParams2.leftMargin + i7;
                view = virtualChildAt;
                view2 = view;
                i9 = i8;
                i8 = virtualChildCount + getLocationOffset(virtualChildAt);
                i13 = paddingTop;
                layoutParams = layoutParams2;
                setChildFrame(view, i8, i11, measuredWidth, i10);
                virtualChildAt = view2;
                i11 = i16 + getChildrenSkipCount(virtualChildAt, i9);
                i7 = virtualChildCount + ((measuredWidth + layoutParams.rightMargin) + getNextLocationOffset(virtualChildAt));
                i11++;
                virtualChildCount = i14;
                i9 = i15;
                i10 = i12;
                paddingTop = i13;
            } else {
                i16 = i11;
                i13 = paddingTop;
                i14 = virtualChildCount;
                i15 = i9;
                i12 = 1;
            }
            i11++;
            virtualChildCount = i14;
            i9 = i15;
            i10 = i12;
            paddingTop = i13;
        }
    }

    private void setChildFrame(View view, int i, int i2, int i3, int i4) {
        view.layout(i, i2, i3 + i, i4 + i2);
    }

    public void setOrientation(int i) {
        if (this.mOrientation != i) {
            this.mOrientation = i;
            requestLayout();
        }
    }

    public int getOrientation() {
        return this.mOrientation;
    }

    public void setGravity(int i) {
        if (this.mGravity != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.mGravity = i;
            requestLayout();
        }
    }

    public int getGravity() {
        return this.mGravity;
    }

    public void setHorizontalGravity(int i) {
        i &= 8388615;
        int i2 = this.mGravity;
        if ((8388615 & i2) != i) {
            this.mGravity = i | (-8388616 & i2);
            requestLayout();
        }
    }

    public void setVerticalGravity(int i) {
        i &= 112;
        int i2 = this.mGravity;
        if ((i2 & 112) != i) {
            this.mGravity = i | (i2 & -113);
            requestLayout();
        }
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    protected LayoutParams generateDefaultLayoutParams() {
        int i = this.mOrientation;
        if (i == 0) {
            return new LayoutParams(-2, -2);
        }
        return i == 1 ? new LayoutParams(-1, -2) : null;
    }

    protected LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(LinearLayoutCompat.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(LinearLayoutCompat.class.getName());
    }
}
