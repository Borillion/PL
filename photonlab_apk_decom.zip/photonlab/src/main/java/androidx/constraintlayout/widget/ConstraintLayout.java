package androidx.constraintlayout.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import androidx.constraintlayout.solver.Metrics;
import androidx.constraintlayout.solver.widgets.Analyzer;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor.Strength;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor.Type;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.ConstraintWidget.DimensionBehaviour;
import androidx.constraintlayout.solver.widgets.ConstraintWidgetContainer;
import androidx.constraintlayout.solver.widgets.Guideline;
import androidx.constraintlayout.solver.widgets.ResolutionAnchor;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
    static final boolean ALLOWS_EMBEDDED = false;
    private static final boolean CACHE_MEASURED_DIMENSION = false;
    private static final boolean DEBUG = false;
    public static final int DESIGN_INFO_ID = 0;
    private static final String TAG = "ConstraintLayout";
    private static final boolean USE_CONSTRAINTS_HELPER = true;
    public static final String VERSION = "ConstraintLayout-1.1.3";
    SparseArray<View> mChildrenByIds = new SparseArray();
    private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList(4);
    private ConstraintSet mConstraintSet = null;
    private int mConstraintSetId = -1;
    private HashMap<String, Integer> mDesignIds = new HashMap();
    private boolean mDirtyHierarchy = true;
    private int mLastMeasureHeight = -1;
    int mLastMeasureHeightMode = 0;
    int mLastMeasureHeightSize = -1;
    private int mLastMeasureWidth = -1;
    int mLastMeasureWidthMode = 0;
    int mLastMeasureWidthSize = -1;
    ConstraintWidgetContainer mLayoutWidget = new ConstraintWidgetContainer();
    private int mMaxHeight = Integer.MAX_VALUE;
    private int mMaxWidth = Integer.MAX_VALUE;
    private Metrics mMetrics;
    private int mMinHeight = 0;
    private int mMinWidth = 0;
    private int mOptimizationLevel = 7;
    private final ArrayList<ConstraintWidget> mVariableDimensionsWidgets = new ArrayList(100);

    public static class LayoutParams extends MarginLayoutParams {
        public static final int BASELINE = 5;
        public static final int BOTTOM = 4;
        public static final int CHAIN_PACKED = 2;
        public static final int CHAIN_SPREAD = 0;
        public static final int CHAIN_SPREAD_INSIDE = 1;
        public static final int END = 7;
        public static final int HORIZONTAL = 0;
        public static final int LEFT = 1;
        public static final int MATCH_CONSTRAINT = 0;
        public static final int MATCH_CONSTRAINT_PERCENT = 2;
        public static final int MATCH_CONSTRAINT_SPREAD = 0;
        public static final int MATCH_CONSTRAINT_WRAP = 1;
        public static final int PARENT_ID = 0;
        public static final int RIGHT = 2;
        public static final int START = 6;
        public static final int TOP = 3;
        public static final int UNSET = -1;
        public static final int VERTICAL = 1;
        public int baselineToBaseline = -1;
        public int bottomToBottom = -1;
        public int bottomToTop = -1;
        public float circleAngle = 0.0f;
        public int circleConstraint = -1;
        public int circleRadius = 0;
        public boolean constrainedHeight = false;
        public boolean constrainedWidth = false;
        public String dimensionRatio = null;
        int dimensionRatioSide = 1;
        float dimensionRatioValue = 0.0f;
        public int editorAbsoluteX = -1;
        public int editorAbsoluteY = -1;
        public int endToEnd = -1;
        public int endToStart = -1;
        public int goneBottomMargin = -1;
        public int goneEndMargin = -1;
        public int goneLeftMargin = -1;
        public int goneRightMargin = -1;
        public int goneStartMargin = -1;
        public int goneTopMargin = -1;
        public int guideBegin = -1;
        public int guideEnd = -1;
        public float guidePercent = -1.0f;
        public boolean helped = false;
        public float horizontalBias = 0.5f;
        public int horizontalChainStyle = 0;
        boolean horizontalDimensionFixed = true;
        public float horizontalWeight = -1.0f;
        boolean isGuideline = false;
        boolean isHelper = false;
        boolean isInPlaceholder = false;
        public int leftToLeft = -1;
        public int leftToRight = -1;
        public int matchConstraintDefaultHeight = 0;
        public int matchConstraintDefaultWidth = 0;
        public int matchConstraintMaxHeight = 0;
        public int matchConstraintMaxWidth = 0;
        public int matchConstraintMinHeight = 0;
        public int matchConstraintMinWidth = 0;
        public float matchConstraintPercentHeight = 1.0f;
        public float matchConstraintPercentWidth = 1.0f;
        boolean needsBaseline = false;
        public int orientation = -1;
        int resolveGoneLeftMargin = -1;
        int resolveGoneRightMargin = -1;
        int resolvedGuideBegin;
        int resolvedGuideEnd;
        float resolvedGuidePercent;
        float resolvedHorizontalBias = 0.5f;
        int resolvedLeftToLeft = -1;
        int resolvedLeftToRight = -1;
        int resolvedRightToLeft = -1;
        int resolvedRightToRight = -1;
        public int rightToLeft = -1;
        public int rightToRight = -1;
        public int startToEnd = -1;
        public int startToStart = -1;
        public int topToBottom = -1;
        public int topToTop = -1;
        public float verticalBias = 0.5f;
        public int verticalChainStyle = 0;
        boolean verticalDimensionFixed = true;
        public float verticalWeight = -1.0f;
        ConstraintWidget widget = new ConstraintWidget();

        private static class Table {
            public static final int ANDROID_ORIENTATION = 1;
            public static final int LAYOUT_CONSTRAINED_HEIGHT = 28;
            public static final int LAYOUT_CONSTRAINED_WIDTH = 27;
            public static final int LAYOUT_CONSTRAINT_BASELINE_CREATOR = 43;
            public static final int LAYOUT_CONSTRAINT_BASELINE_TO_BASELINE_OF = 16;
            public static final int LAYOUT_CONSTRAINT_BOTTOM_CREATOR = 42;
            public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_BOTTOM_OF = 15;
            public static final int LAYOUT_CONSTRAINT_BOTTOM_TO_TOP_OF = 14;
            public static final int LAYOUT_CONSTRAINT_CIRCLE = 2;
            public static final int LAYOUT_CONSTRAINT_CIRCLE_ANGLE = 4;
            public static final int LAYOUT_CONSTRAINT_CIRCLE_RADIUS = 3;
            public static final int LAYOUT_CONSTRAINT_DIMENSION_RATIO = 44;
            public static final int LAYOUT_CONSTRAINT_END_TO_END_OF = 20;
            public static final int LAYOUT_CONSTRAINT_END_TO_START_OF = 19;
            public static final int LAYOUT_CONSTRAINT_GUIDE_BEGIN = 5;
            public static final int LAYOUT_CONSTRAINT_GUIDE_END = 6;
            public static final int LAYOUT_CONSTRAINT_GUIDE_PERCENT = 7;
            public static final int LAYOUT_CONSTRAINT_HEIGHT_DEFAULT = 32;
            public static final int LAYOUT_CONSTRAINT_HEIGHT_MAX = 37;
            public static final int LAYOUT_CONSTRAINT_HEIGHT_MIN = 36;
            public static final int LAYOUT_CONSTRAINT_HEIGHT_PERCENT = 38;
            public static final int LAYOUT_CONSTRAINT_HORIZONTAL_BIAS = 29;
            public static final int LAYOUT_CONSTRAINT_HORIZONTAL_CHAINSTYLE = 47;
            public static final int LAYOUT_CONSTRAINT_HORIZONTAL_WEIGHT = 45;
            public static final int LAYOUT_CONSTRAINT_LEFT_CREATOR = 39;
            public static final int LAYOUT_CONSTRAINT_LEFT_TO_LEFT_OF = 8;
            public static final int LAYOUT_CONSTRAINT_LEFT_TO_RIGHT_OF = 9;
            public static final int LAYOUT_CONSTRAINT_RIGHT_CREATOR = 41;
            public static final int LAYOUT_CONSTRAINT_RIGHT_TO_LEFT_OF = 10;
            public static final int LAYOUT_CONSTRAINT_RIGHT_TO_RIGHT_OF = 11;
            public static final int LAYOUT_CONSTRAINT_START_TO_END_OF = 17;
            public static final int LAYOUT_CONSTRAINT_START_TO_START_OF = 18;
            public static final int LAYOUT_CONSTRAINT_TOP_CREATOR = 40;
            public static final int LAYOUT_CONSTRAINT_TOP_TO_BOTTOM_OF = 13;
            public static final int LAYOUT_CONSTRAINT_TOP_TO_TOP_OF = 12;
            public static final int LAYOUT_CONSTRAINT_VERTICAL_BIAS = 30;
            public static final int LAYOUT_CONSTRAINT_VERTICAL_CHAINSTYLE = 48;
            public static final int LAYOUT_CONSTRAINT_VERTICAL_WEIGHT = 46;
            public static final int LAYOUT_CONSTRAINT_WIDTH_DEFAULT = 31;
            public static final int LAYOUT_CONSTRAINT_WIDTH_MAX = 34;
            public static final int LAYOUT_CONSTRAINT_WIDTH_MIN = 33;
            public static final int LAYOUT_CONSTRAINT_WIDTH_PERCENT = 35;
            public static final int LAYOUT_EDITOR_ABSOLUTEX = 49;
            public static final int LAYOUT_EDITOR_ABSOLUTEY = 50;
            public static final int LAYOUT_GONE_MARGIN_BOTTOM = 24;
            public static final int LAYOUT_GONE_MARGIN_END = 26;
            public static final int LAYOUT_GONE_MARGIN_LEFT = 21;
            public static final int LAYOUT_GONE_MARGIN_RIGHT = 23;
            public static final int LAYOUT_GONE_MARGIN_START = 25;
            public static final int LAYOUT_GONE_MARGIN_TOP = 22;
            public static final int UNUSED = 0;
            public static final SparseIntArray map = new SparseIntArray();

            private Table() {
            }

            static {
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
                map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
                map.append(R.styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
                map.append(R.styleable.ConstraintLayout_Layout_android_orientation, 1);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
                map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
                map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
                map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
                map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
                map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
                map.append(R.styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
                map.append(R.styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
            }
        }

        public void reset() {
            ConstraintWidget constraintWidget = this.widget;
            if (constraintWidget != null) {
                constraintWidget.reset();
            }
        }

        public LayoutParams(LayoutParams layoutParams) {
            super(layoutParams);
            this.guideBegin = layoutParams.guideBegin;
            this.guideEnd = layoutParams.guideEnd;
            this.guidePercent = layoutParams.guidePercent;
            this.leftToLeft = layoutParams.leftToLeft;
            this.leftToRight = layoutParams.leftToRight;
            this.rightToLeft = layoutParams.rightToLeft;
            this.rightToRight = layoutParams.rightToRight;
            this.topToTop = layoutParams.topToTop;
            this.topToBottom = layoutParams.topToBottom;
            this.bottomToTop = layoutParams.bottomToTop;
            this.bottomToBottom = layoutParams.bottomToBottom;
            this.baselineToBaseline = layoutParams.baselineToBaseline;
            this.circleConstraint = layoutParams.circleConstraint;
            this.circleRadius = layoutParams.circleRadius;
            this.circleAngle = layoutParams.circleAngle;
            this.startToEnd = layoutParams.startToEnd;
            this.startToStart = layoutParams.startToStart;
            this.endToStart = layoutParams.endToStart;
            this.endToEnd = layoutParams.endToEnd;
            this.goneLeftMargin = layoutParams.goneLeftMargin;
            this.goneTopMargin = layoutParams.goneTopMargin;
            this.goneRightMargin = layoutParams.goneRightMargin;
            this.goneBottomMargin = layoutParams.goneBottomMargin;
            this.goneStartMargin = layoutParams.goneStartMargin;
            this.goneEndMargin = layoutParams.goneEndMargin;
            this.horizontalBias = layoutParams.horizontalBias;
            this.verticalBias = layoutParams.verticalBias;
            this.dimensionRatio = layoutParams.dimensionRatio;
            this.dimensionRatioValue = layoutParams.dimensionRatioValue;
            this.dimensionRatioSide = layoutParams.dimensionRatioSide;
            this.horizontalWeight = layoutParams.horizontalWeight;
            this.verticalWeight = layoutParams.verticalWeight;
            this.horizontalChainStyle = layoutParams.horizontalChainStyle;
            this.verticalChainStyle = layoutParams.verticalChainStyle;
            this.constrainedWidth = layoutParams.constrainedWidth;
            this.constrainedHeight = layoutParams.constrainedHeight;
            this.matchConstraintDefaultWidth = layoutParams.matchConstraintDefaultWidth;
            this.matchConstraintDefaultHeight = layoutParams.matchConstraintDefaultHeight;
            this.matchConstraintMinWidth = layoutParams.matchConstraintMinWidth;
            this.matchConstraintMaxWidth = layoutParams.matchConstraintMaxWidth;
            this.matchConstraintMinHeight = layoutParams.matchConstraintMinHeight;
            this.matchConstraintMaxHeight = layoutParams.matchConstraintMaxHeight;
            this.matchConstraintPercentWidth = layoutParams.matchConstraintPercentWidth;
            this.matchConstraintPercentHeight = layoutParams.matchConstraintPercentHeight;
            this.editorAbsoluteX = layoutParams.editorAbsoluteX;
            this.editorAbsoluteY = layoutParams.editorAbsoluteY;
            this.orientation = layoutParams.orientation;
            this.horizontalDimensionFixed = layoutParams.horizontalDimensionFixed;
            this.verticalDimensionFixed = layoutParams.verticalDimensionFixed;
            this.needsBaseline = layoutParams.needsBaseline;
            this.isGuideline = layoutParams.isGuideline;
            this.resolvedLeftToLeft = layoutParams.resolvedLeftToLeft;
            this.resolvedLeftToRight = layoutParams.resolvedLeftToRight;
            this.resolvedRightToLeft = layoutParams.resolvedRightToLeft;
            this.resolvedRightToRight = layoutParams.resolvedRightToRight;
            this.resolveGoneLeftMargin = layoutParams.resolveGoneLeftMargin;
            this.resolveGoneRightMargin = layoutParams.resolveGoneRightMargin;
            this.resolvedHorizontalBias = layoutParams.resolvedHorizontalBias;
            this.widget = layoutParams.widget;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.ConstraintLayout_Layout);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                String str = "ConstraintLayout";
                float f;
                switch (Table.map.get(index)) {
                    case 1:
                        this.orientation = obtainStyledAttributes.getInt(index, this.orientation);
                    case 2:
                        this.circleConstraint = obtainStyledAttributes.getResourceId(index, this.circleConstraint);
                        if (this.circleConstraint == -1) {
                            this.circleConstraint = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 3:
                        this.circleRadius = obtainStyledAttributes.getDimensionPixelSize(index, this.circleRadius);
                    case 4:
                        this.circleAngle = obtainStyledAttributes.getFloat(index, this.circleAngle) % 360.0f;
                        f = this.circleAngle;
                        if (f < 0.0f) {
                            this.circleAngle = (360.0f - f) % 360.0f;
                        }
                    case 5:
                        this.guideBegin = obtainStyledAttributes.getDimensionPixelOffset(index, this.guideBegin);
                    case 6:
                        this.guideEnd = obtainStyledAttributes.getDimensionPixelOffset(index, this.guideEnd);
                    case 7:
                        this.guidePercent = obtainStyledAttributes.getFloat(index, this.guidePercent);
                    case 8:
                        this.leftToLeft = obtainStyledAttributes.getResourceId(index, this.leftToLeft);
                        if (this.leftToLeft == -1) {
                            this.leftToLeft = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 9:
                        this.leftToRight = obtainStyledAttributes.getResourceId(index, this.leftToRight);
                        if (this.leftToRight == -1) {
                            this.leftToRight = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 10:
                        this.rightToLeft = obtainStyledAttributes.getResourceId(index, this.rightToLeft);
                        if (this.rightToLeft == -1) {
                            this.rightToLeft = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 11:
                        this.rightToRight = obtainStyledAttributes.getResourceId(index, this.rightToRight);
                        if (this.rightToRight == -1) {
                            this.rightToRight = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 12:
                        this.topToTop = obtainStyledAttributes.getResourceId(index, this.topToTop);
                        if (this.topToTop == -1) {
                            this.topToTop = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 13:
                        this.topToBottom = obtainStyledAttributes.getResourceId(index, this.topToBottom);
                        if (this.topToBottom == -1) {
                            this.topToBottom = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 14:
                        this.bottomToTop = obtainStyledAttributes.getResourceId(index, this.bottomToTop);
                        if (this.bottomToTop == -1) {
                            this.bottomToTop = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 15:
                        this.bottomToBottom = obtainStyledAttributes.getResourceId(index, this.bottomToBottom);
                        if (this.bottomToBottom == -1) {
                            this.bottomToBottom = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 16:
                        this.baselineToBaseline = obtainStyledAttributes.getResourceId(index, this.baselineToBaseline);
                        if (this.baselineToBaseline == -1) {
                            this.baselineToBaseline = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 17:
                        this.startToEnd = obtainStyledAttributes.getResourceId(index, this.startToEnd);
                        if (this.startToEnd == -1) {
                            this.startToEnd = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 18:
                        this.startToStart = obtainStyledAttributes.getResourceId(index, this.startToStart);
                        if (this.startToStart == -1) {
                            this.startToStart = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 19:
                        this.endToStart = obtainStyledAttributes.getResourceId(index, this.endToStart);
                        if (this.endToStart == -1) {
                            this.endToStart = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 20:
                        this.endToEnd = obtainStyledAttributes.getResourceId(index, this.endToEnd);
                        if (this.endToEnd == -1) {
                            this.endToEnd = obtainStyledAttributes.getInt(index, -1);
                        }
                    case 21:
                        this.goneLeftMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneLeftMargin);
                    case 22:
                        this.goneTopMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneTopMargin);
                    case 23:
                        this.goneRightMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneRightMargin);
                    case 24:
                        this.goneBottomMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneBottomMargin);
                    case 25:
                        this.goneStartMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneStartMargin);
                    case 26:
                        this.goneEndMargin = obtainStyledAttributes.getDimensionPixelSize(index, this.goneEndMargin);
                    case 27:
                        this.constrainedWidth = obtainStyledAttributes.getBoolean(index, this.constrainedWidth);
                    case 28:
                        this.constrainedHeight = obtainStyledAttributes.getBoolean(index, this.constrainedHeight);
                    case 29:
                        this.horizontalBias = obtainStyledAttributes.getFloat(index, this.horizontalBias);
                    case 30:
                        this.verticalBias = obtainStyledAttributes.getFloat(index, this.verticalBias);
                    case 31:
                        this.matchConstraintDefaultWidth = obtainStyledAttributes.getInt(index, 0);
                        if (this.matchConstraintDefaultWidth == 1) {
                            Log.e(str, "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        }
                    case 32:
                        this.matchConstraintDefaultHeight = obtainStyledAttributes.getInt(index, 0);
                        if (this.matchConstraintDefaultHeight == 1) {
                            Log.e(str, "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        }
                    case 33:
                        try {
                            this.matchConstraintMinWidth = obtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMinWidth);
                        } catch (Exception unused) {
                            if (obtainStyledAttributes.getInt(index, this.matchConstraintMinWidth) == -2) {
                                this.matchConstraintMinWidth = -2;
                            }
                        }
                    case 34:
                        try {
                            this.matchConstraintMaxWidth = obtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMaxWidth);
                        } catch (Exception unused2) {
                            if (obtainStyledAttributes.getInt(index, this.matchConstraintMaxWidth) == -2) {
                                this.matchConstraintMaxWidth = -2;
                            }
                        }
                    case 35:
                        this.matchConstraintPercentWidth = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.matchConstraintPercentWidth));
                    case 36:
                        try {
                            this.matchConstraintMinHeight = obtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMinHeight);
                        } catch (Exception unused3) {
                            if (obtainStyledAttributes.getInt(index, this.matchConstraintMinHeight) == -2) {
                                this.matchConstraintMinHeight = -2;
                            }
                        }
                    case 37:
                        try {
                            this.matchConstraintMaxHeight = obtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMaxHeight);
                        } catch (Exception unused4) {
                            if (obtainStyledAttributes.getInt(index, this.matchConstraintMaxHeight) == -2) {
                                this.matchConstraintMaxHeight = -2;
                            }
                        }
                    case 38:
                        this.matchConstraintPercentHeight = Math.max(0.0f, obtainStyledAttributes.getFloat(index, this.matchConstraintPercentHeight));
                    case 44:
                        this.dimensionRatio = obtainStyledAttributes.getString(index);
                        this.dimensionRatioValue = Float.NaN;
                        this.dimensionRatioSide = -1;
                        String str2 = this.dimensionRatio;
                        if (str2 != null) {
                            index = str2.length();
                            int indexOf = this.dimensionRatio.indexOf(44);
                            if (indexOf <= 0 || indexOf >= index - 1) {
                                indexOf = 0;
                            } else {
                                str = this.dimensionRatio.substring(0, indexOf);
                                if (str.equalsIgnoreCase("W")) {
                                    this.dimensionRatioSide = 0;
                                } else if (str.equalsIgnoreCase("H")) {
                                    this.dimensionRatioSide = 1;
                                }
                                indexOf++;
                            }
                            int indexOf2 = this.dimensionRatio.indexOf(58);
                            if (indexOf2 < 0 || indexOf2 >= index - 1) {
                                str2 = this.dimensionRatio.substring(indexOf);
                                if (str2.length() > 0) {
                                    this.dimensionRatioValue = Float.parseFloat(str2);
                                }
                            } else {
                                str2 = this.dimensionRatio.substring(indexOf, indexOf2);
                                String substring = this.dimensionRatio.substring(indexOf2 + 1);
                                if (str2.length() > 0 && substring.length() > 0) {
                                    try {
                                        f = Float.parseFloat(str2);
                                        float parseFloat = Float.parseFloat(substring);
                                        if (f > 0.0f && parseFloat > 0.0f) {
                                            if (this.dimensionRatioSide == 1) {
                                                this.dimensionRatioValue = Math.abs(parseFloat / f);
                                            } else {
                                                this.dimensionRatioValue = Math.abs(f / parseFloat);
                                            }
                                        }
                                    } catch (NumberFormatException unused5) {
                                    }
                                }
                            }
                        }
                        break;
                    case 45:
                        this.horizontalWeight = obtainStyledAttributes.getFloat(index, this.horizontalWeight);
                    case 46:
                        this.verticalWeight = obtainStyledAttributes.getFloat(index, this.verticalWeight);
                    case 47:
                        this.horizontalChainStyle = obtainStyledAttributes.getInt(index, 0);
                    case 48:
                        this.verticalChainStyle = obtainStyledAttributes.getInt(index, 0);
                    case 49:
                        this.editorAbsoluteX = obtainStyledAttributes.getDimensionPixelOffset(index, this.editorAbsoluteX);
                    case 50:
                        this.editorAbsoluteY = obtainStyledAttributes.getDimensionPixelOffset(index, this.editorAbsoluteY);
                    default:
                }
            }
            obtainStyledAttributes.recycle();
            validate();
        }

        public void validate() {
            this.isGuideline = false;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            if (this.width == -2 && this.constrainedWidth) {
                this.horizontalDimensionFixed = false;
                this.matchConstraintDefaultWidth = 1;
            }
            if (this.height == -2 && this.constrainedHeight) {
                this.verticalDimensionFixed = false;
                this.matchConstraintDefaultHeight = 1;
            }
            if (this.width == 0 || this.width == -1) {
                this.horizontalDimensionFixed = false;
                if (this.width == 0 && this.matchConstraintDefaultWidth == 1) {
                    this.width = -2;
                    this.constrainedWidth = true;
                }
            }
            if (this.height == 0 || this.height == -1) {
                this.verticalDimensionFixed = false;
                if (this.height == 0 && this.matchConstraintDefaultHeight == 1) {
                    this.height = -2;
                    this.constrainedHeight = true;
                }
            }
            if (this.guidePercent != -1.0f || this.guideBegin != -1 || this.guideEnd != -1) {
                this.isGuideline = true;
                this.horizontalDimensionFixed = true;
                this.verticalDimensionFixed = true;
                if (!(this.widget instanceof Guideline)) {
                    this.widget = new Guideline();
                }
                ((Guideline) this.widget).setOrientation(this.orientation);
            }
        }

        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        /* JADX WARNING: Removed duplicated region for block: B:14:0x004c  */
        /* JADX WARNING: Removed duplicated region for block: B:17:0x0053  */
        /* JADX WARNING: Removed duplicated region for block: B:20:0x005a  */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x0060  */
        /* JADX WARNING: Removed duplicated region for block: B:26:0x0066  */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x0084  */
        /* JADX WARNING: Removed duplicated region for block: B:33:0x007c  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        @TargetApi(17)
        public void resolveLayoutDirection(int i) {
            int i2;
            int i3 = this.leftMargin;
            int i4 = this.rightMargin;
            super.resolveLayoutDirection(i);
            this.resolvedRightToLeft = -1;
            this.resolvedRightToRight = -1;
            this.resolvedLeftToLeft = -1;
            this.resolvedLeftToRight = -1;
            this.resolveGoneLeftMargin = -1;
            this.resolveGoneRightMargin = -1;
            this.resolveGoneLeftMargin = this.goneLeftMargin;
            this.resolveGoneRightMargin = this.goneRightMargin;
            this.resolvedHorizontalBias = this.horizontalBias;
            this.resolvedGuideBegin = this.guideBegin;
            this.resolvedGuideEnd = this.guideEnd;
            this.resolvedGuidePercent = this.guidePercent;
            Object obj = null;
            if ((1 == getLayoutDirection() ? 1 : null) != null) {
                float f;
                i2 = this.startToEnd;
                if (i2 != -1) {
                    this.resolvedRightToLeft = i2;
                } else {
                    i2 = this.startToStart;
                    if (i2 != -1) {
                        this.resolvedRightToRight = i2;
                    }
                    i2 = this.endToStart;
                    if (i2 != -1) {
                        this.resolvedLeftToRight = i2;
                        obj = 1;
                    }
                    i2 = this.endToEnd;
                    if (i2 != -1) {
                        this.resolvedLeftToLeft = i2;
                        obj = 1;
                    }
                    i2 = this.goneStartMargin;
                    if (i2 != -1) {
                        this.resolveGoneRightMargin = i2;
                    }
                    i2 = this.goneEndMargin;
                    if (i2 != -1) {
                        this.resolveGoneLeftMargin = i2;
                    }
                    if (obj != null) {
                        this.resolvedHorizontalBias = 1.0f - this.horizontalBias;
                    }
                    if (this.isGuideline && this.orientation == 1) {
                        f = this.guidePercent;
                        if (f == -1.0f) {
                            this.resolvedGuidePercent = 1.0f - f;
                            this.resolvedGuideBegin = -1;
                            this.resolvedGuideEnd = -1;
                        } else {
                            i2 = this.guideBegin;
                            if (i2 != -1) {
                                this.resolvedGuideEnd = i2;
                                this.resolvedGuideBegin = -1;
                                this.resolvedGuidePercent = -1.0f;
                            } else {
                                i2 = this.guideEnd;
                                if (i2 != -1) {
                                    this.resolvedGuideBegin = i2;
                                    this.resolvedGuideEnd = -1;
                                    this.resolvedGuidePercent = -1.0f;
                                }
                            }
                        }
                    }
                }
                obj = 1;
                i2 = this.endToStart;
                if (i2 != -1) {
                }
                i2 = this.endToEnd;
                if (i2 != -1) {
                }
                i2 = this.goneStartMargin;
                if (i2 != -1) {
                }
                i2 = this.goneEndMargin;
                if (i2 != -1) {
                }
                if (obj != null) {
                }
                f = this.guidePercent;
                if (f == -1.0f) {
                }
            } else {
                i2 = this.startToEnd;
                if (i2 != -1) {
                    this.resolvedLeftToRight = i2;
                }
                i2 = this.startToStart;
                if (i2 != -1) {
                    this.resolvedLeftToLeft = i2;
                }
                i2 = this.endToStart;
                if (i2 != -1) {
                    this.resolvedRightToLeft = i2;
                }
                i2 = this.endToEnd;
                if (i2 != -1) {
                    this.resolvedRightToRight = i2;
                }
                i2 = this.goneStartMargin;
                if (i2 != -1) {
                    this.resolveGoneLeftMargin = i2;
                }
                i2 = this.goneEndMargin;
                if (i2 != -1) {
                    this.resolveGoneRightMargin = i2;
                }
            }
            if (this.endToStart == -1 && this.endToEnd == -1 && this.startToStart == -1 && this.startToEnd == -1) {
                i2 = this.rightToLeft;
                if (i2 != -1) {
                    this.resolvedRightToLeft = i2;
                    if (this.rightMargin <= 0 && i4 > 0) {
                        this.rightMargin = i4;
                    }
                } else {
                    i2 = this.rightToRight;
                    if (i2 != -1) {
                        this.resolvedRightToRight = i2;
                        if (this.rightMargin <= 0 && i4 > 0) {
                            this.rightMargin = i4;
                        }
                    }
                }
                i4 = this.leftToLeft;
                if (i4 != -1) {
                    this.resolvedLeftToLeft = i4;
                    if (this.leftMargin <= 0 && i3 > 0) {
                        this.leftMargin = i3;
                        return;
                    }
                    return;
                }
                i4 = this.leftToRight;
                if (i4 != -1) {
                    this.resolvedLeftToRight = i4;
                    if (this.leftMargin <= 0 && i3 > 0) {
                        this.leftMargin = i3;
                    }
                }
            }
        }
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public void setDesignInformation(int i, Object obj, Object obj2) {
        if (i == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.mDesignIds == null) {
                this.mDesignIds = new HashMap();
            }
            obj = (String) obj;
            i = obj.indexOf("/");
            if (i != -1) {
                obj = obj.substring(i + 1);
            }
            this.mDesignIds.put(obj, Integer.valueOf(((Integer) obj2).intValue()));
        }
    }

    public Object getDesignInformation(int i, Object obj) {
        if (i == 0 && (obj instanceof String)) {
            String str = (String) obj;
            HashMap hashMap = this.mDesignIds;
            if (hashMap != null && hashMap.containsKey(str)) {
                return this.mDesignIds.get(str);
            }
        }
        return null;
    }

    public ConstraintLayout(Context context) {
        super(context);
        init(null);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(attributeSet);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(attributeSet);
    }

    public void setId(int i) {
        this.mChildrenByIds.remove(getId());
        super.setId(i);
        this.mChildrenByIds.put(getId(), this);
    }

    private void init(AttributeSet attributeSet) {
        this.mLayoutWidget.setCompanionWidget(this);
        this.mChildrenByIds.put(getId(), this);
        this.mConstraintSet = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R.styleable.ConstraintLayout_Layout);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == R.styleable.ConstraintLayout_Layout_android_minWidth) {
                    this.mMinWidth = obtainStyledAttributes.getDimensionPixelOffset(index, this.mMinWidth);
                } else if (index == R.styleable.ConstraintLayout_Layout_android_minHeight) {
                    this.mMinHeight = obtainStyledAttributes.getDimensionPixelOffset(index, this.mMinHeight);
                } else if (index == R.styleable.ConstraintLayout_Layout_android_maxWidth) {
                    this.mMaxWidth = obtainStyledAttributes.getDimensionPixelOffset(index, this.mMaxWidth);
                } else if (index == R.styleable.ConstraintLayout_Layout_android_maxHeight) {
                    this.mMaxHeight = obtainStyledAttributes.getDimensionPixelOffset(index, this.mMaxHeight);
                } else if (index == R.styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
                    this.mOptimizationLevel = obtainStyledAttributes.getInt(index, this.mOptimizationLevel);
                } else if (index == R.styleable.ConstraintLayout_Layout_constraintSet) {
                    index = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        this.mConstraintSet = new ConstraintSet();
                        this.mConstraintSet.load(getContext(), index);
                    } catch (NotFoundException unused) {
                        this.mConstraintSet = null;
                    }
                    this.mConstraintSetId = index;
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.mLayoutWidget.setOptimizationLevel(this.mOptimizationLevel);
    }

    public void addView(View view, int i, android.view.ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        if (VERSION.SDK_INT < 14) {
            onViewAdded(view);
        }
    }

    public void removeView(View view) {
        super.removeView(view);
        if (VERSION.SDK_INT < 14) {
            onViewRemoved(view);
        }
    }

    public void onViewAdded(View view) {
        if (VERSION.SDK_INT >= 14) {
            super.onViewAdded(view);
        }
        ConstraintWidget viewWidget = getViewWidget(view);
        if ((view instanceof Guideline) && !(viewWidget instanceof Guideline)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            layoutParams.widget = new Guideline();
            layoutParams.isGuideline = true;
            ((Guideline) layoutParams.widget).setOrientation(layoutParams.orientation);
        }
        if (view instanceof ConstraintHelper) {
            ConstraintHelper constraintHelper = (ConstraintHelper) view;
            constraintHelper.validateParams();
            ((LayoutParams) view.getLayoutParams()).isHelper = true;
            if (!this.mConstraintHelpers.contains(constraintHelper)) {
                this.mConstraintHelpers.add(constraintHelper);
            }
        }
        this.mChildrenByIds.put(view.getId(), view);
        this.mDirtyHierarchy = true;
    }

    public void onViewRemoved(View view) {
        if (VERSION.SDK_INT >= 14) {
            super.onViewRemoved(view);
        }
        this.mChildrenByIds.remove(view.getId());
        ConstraintWidget viewWidget = getViewWidget(view);
        this.mLayoutWidget.remove(viewWidget);
        this.mConstraintHelpers.remove(view);
        this.mVariableDimensionsWidgets.remove(viewWidget);
        this.mDirtyHierarchy = true;
    }

    public void setMinWidth(int i) {
        if (i != this.mMinWidth) {
            this.mMinWidth = i;
            requestLayout();
        }
    }

    public void setMinHeight(int i) {
        if (i != this.mMinHeight) {
            this.mMinHeight = i;
            requestLayout();
        }
    }

    public int getMinWidth() {
        return this.mMinWidth;
    }

    public int getMinHeight() {
        return this.mMinHeight;
    }

    public void setMaxWidth(int i) {
        if (i != this.mMaxWidth) {
            this.mMaxWidth = i;
            requestLayout();
        }
    }

    public void setMaxHeight(int i) {
        if (i != this.mMaxHeight) {
            this.mMaxHeight = i;
            requestLayout();
        }
    }

    public int getMaxWidth() {
        return this.mMaxWidth;
    }

    public int getMaxHeight() {
        return this.mMaxHeight;
    }

    private void updateHierarchy() {
        int childCount = getChildCount();
        Object obj = null;
        for (int i = 0; i < childCount; i++) {
            if (getChildAt(i).isLayoutRequested()) {
                obj = 1;
                break;
            }
        }
        if (obj != null) {
            this.mVariableDimensionsWidgets.clear();
            setChildrenConstraints();
        }
    }

    private void setChildrenConstraints() {
        int i;
        View childAt;
        String resourceName;
        int indexOf;
        ConstraintWidget viewWidget;
        int i2;
        boolean isInEditMode = isInEditMode();
        int childCount = getChildCount();
        boolean z = false;
        if (isInEditMode) {
            i = 0;
            while (i < childCount) {
                childAt = getChildAt(i);
                try {
                    resourceName = getResources().getResourceName(childAt.getId());
                    setDesignInformation(0, resourceName, Integer.valueOf(childAt.getId()));
                    indexOf = resourceName.indexOf(47);
                    if (indexOf != -1) {
                        resourceName = resourceName.substring(indexOf + 1);
                    }
                    getTargetWidget(childAt.getId()).setDebugName(resourceName);
                } catch (NotFoundException unused) {
                    i++;
                }
            }
        }
        for (i = 0; i < childCount; i++) {
            viewWidget = getViewWidget(getChildAt(i));
            if (viewWidget != null) {
                viewWidget.reset();
            }
        }
        if (this.mConstraintSetId != -1) {
            for (i = 0; i < childCount; i++) {
                childAt = getChildAt(i);
                if (childAt.getId() == this.mConstraintSetId && (childAt instanceof Constraints)) {
                    this.mConstraintSet = ((Constraints) childAt).getConstraintSet();
                }
            }
        }
        ConstraintSet constraintSet = this.mConstraintSet;
        if (constraintSet != null) {
            constraintSet.applyToInternal(this);
        }
        this.mLayoutWidget.removeAllChildren();
        i = this.mConstraintHelpers.size();
        if (i > 0) {
            for (i2 = 0; i2 < i; i2++) {
                ((ConstraintHelper) this.mConstraintHelpers.get(i2)).updatePreLayout(this);
            }
        }
        for (i = 0; i < childCount; i++) {
            childAt = getChildAt(i);
            if (childAt instanceof Placeholder) {
                ((Placeholder) childAt).updatePreLayout(this);
            }
        }
        for (i = 0; i < childCount; i++) {
            childAt = getChildAt(i);
            ConstraintWidget viewWidget2 = getViewWidget(childAt);
            if (viewWidget2 != null) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                layoutParams.validate();
                if (layoutParams.helped) {
                    layoutParams.helped = z;
                } else if (isInEditMode) {
                    try {
                        resourceName = getResources().getResourceName(childAt.getId());
                        setDesignInformation(z, resourceName, Integer.valueOf(childAt.getId()));
                        getTargetWidget(childAt.getId()).setDebugName(resourceName.substring(resourceName.indexOf("id/") + 3));
                    } catch (NotFoundException unused2) {
                        viewWidget2.setVisibility(childAt.getVisibility());
                        if (layoutParams.isInPlaceholder) {
                            viewWidget2.setVisibility(8);
                        }
                        viewWidget2.setCompanionWidget(childAt);
                        this.mLayoutWidget.add(viewWidget2);
                        if (!(layoutParams.verticalDimensionFixed && layoutParams.horizontalDimensionFixed)) {
                            this.mVariableDimensionsWidgets.add(viewWidget2);
                        }
                        if (layoutParams.isGuideline) {
                            Guideline guideline = (Guideline) viewWidget2;
                            i2 = layoutParams.resolvedGuideBegin;
                            indexOf = layoutParams.resolvedGuideEnd;
                            float f = layoutParams.resolvedGuidePercent;
                            if (VERSION.SDK_INT < 17) {
                                i2 = layoutParams.guideBegin;
                                indexOf = layoutParams.guideEnd;
                                f = layoutParams.guidePercent;
                            }
                            if (f != -1.0f) {
                                guideline.setGuidePercent(f);
                            } else if (i2 != -1) {
                                guideline.setGuideBegin(i2);
                            } else if (indexOf != -1) {
                                guideline.setGuideEnd(indexOf);
                            }
                        } else if (layoutParams.leftToLeft != -1 || layoutParams.leftToRight != -1 || layoutParams.rightToLeft != -1 || layoutParams.rightToRight != -1 || layoutParams.startToStart != -1 || layoutParams.startToEnd != -1 || layoutParams.endToStart != -1 || layoutParams.endToEnd != -1 || layoutParams.topToTop != -1 || layoutParams.topToBottom != -1 || layoutParams.bottomToTop != -1 || layoutParams.bottomToBottom != -1 || layoutParams.baselineToBaseline != -1 || layoutParams.editorAbsoluteX != -1 || layoutParams.editorAbsoluteY != -1 || layoutParams.circleConstraint != -1 || layoutParams.width == -1 || layoutParams.height == -1) {
                            int i3;
                            int i4;
                            i2 = layoutParams.resolvedLeftToLeft;
                            indexOf = layoutParams.resolvedLeftToRight;
                            int i5 = layoutParams.resolvedRightToLeft;
                            int i6 = layoutParams.resolvedRightToRight;
                            int i7 = layoutParams.resolveGoneLeftMargin;
                            int i8 = layoutParams.resolveGoneRightMargin;
                            float f2 = layoutParams.resolvedHorizontalBias;
                            if (VERSION.SDK_INT < 17) {
                                i3 = layoutParams.leftToLeft;
                                i2 = layoutParams.leftToRight;
                                i5 = layoutParams.rightToLeft;
                                i6 = layoutParams.rightToRight;
                                int i9 = layoutParams.goneLeftMargin;
                                indexOf = layoutParams.goneRightMargin;
                                f2 = layoutParams.horizontalBias;
                                if (i3 == -1 && i2 == -1) {
                                    if (layoutParams.startToStart != -1) {
                                        i3 = layoutParams.startToStart;
                                    } else if (layoutParams.startToEnd != -1) {
                                        i2 = layoutParams.startToEnd;
                                    }
                                }
                                int i10 = i2;
                                i2 = i3;
                                i3 = i10;
                                if (i5 == -1 && i6 == -1) {
                                    if (layoutParams.endToStart != -1) {
                                        i5 = layoutParams.endToStart;
                                    } else if (layoutParams.endToEnd != -1) {
                                        i6 = layoutParams.endToEnd;
                                    }
                                }
                                i8 = i9;
                                i4 = indexOf;
                            } else {
                                i3 = indexOf;
                                i4 = i8;
                                i8 = i7;
                            }
                            i7 = i6;
                            float f3 = f2;
                            int i11 = i5;
                            if (layoutParams.circleConstraint != -1) {
                                ConstraintWidget targetWidget = getTargetWidget(layoutParams.circleConstraint);
                                if (targetWidget != null) {
                                    viewWidget2.connectCircularConstraint(targetWidget, layoutParams.circleAngle, layoutParams.circleRadius);
                                }
                            } else {
                                ConstraintWidget targetWidget2;
                                float f4;
                                if (i2 != -1) {
                                    targetWidget2 = getTargetWidget(i2);
                                    if (targetWidget2 != null) {
                                        Type type = Type.LEFT;
                                        f4 = f3;
                                        Type type2 = Type.LEFT;
                                        i3 = i7;
                                        viewWidget2.immediateConnect(type, targetWidget2, type2, layoutParams.leftMargin, i8);
                                    } else {
                                        f4 = f3;
                                        i3 = i7;
                                    }
                                    i2 = i3;
                                } else {
                                    f4 = f3;
                                    i2 = i7;
                                    if (i3 != -1) {
                                        targetWidget2 = getTargetWidget(i3);
                                        if (targetWidget2 != null) {
                                            viewWidget2.immediateConnect(Type.LEFT, targetWidget2, Type.RIGHT, layoutParams.leftMargin, i8);
                                        }
                                    }
                                }
                                if (i11 != -1) {
                                    targetWidget2 = getTargetWidget(i11);
                                    if (targetWidget2 != null) {
                                        viewWidget2.immediateConnect(Type.RIGHT, targetWidget2, Type.LEFT, layoutParams.rightMargin, i4);
                                    }
                                } else if (i2 != -1) {
                                    targetWidget2 = getTargetWidget(i2);
                                    if (targetWidget2 != null) {
                                        viewWidget2.immediateConnect(Type.RIGHT, targetWidget2, Type.RIGHT, layoutParams.rightMargin, i4);
                                    }
                                }
                                if (layoutParams.topToTop != -1) {
                                    targetWidget2 = getTargetWidget(layoutParams.topToTop);
                                    if (targetWidget2 != null) {
                                        viewWidget2.immediateConnect(Type.TOP, targetWidget2, Type.TOP, layoutParams.topMargin, layoutParams.goneTopMargin);
                                    }
                                } else if (layoutParams.topToBottom != -1) {
                                    targetWidget2 = getTargetWidget(layoutParams.topToBottom);
                                    if (targetWidget2 != null) {
                                        viewWidget2.immediateConnect(Type.TOP, targetWidget2, Type.BOTTOM, layoutParams.topMargin, layoutParams.goneTopMargin);
                                    }
                                }
                                if (layoutParams.bottomToTop != -1) {
                                    targetWidget2 = getTargetWidget(layoutParams.bottomToTop);
                                    if (targetWidget2 != null) {
                                        viewWidget2.immediateConnect(Type.BOTTOM, targetWidget2, Type.TOP, layoutParams.bottomMargin, layoutParams.goneBottomMargin);
                                    }
                                } else if (layoutParams.bottomToBottom != -1) {
                                    targetWidget2 = getTargetWidget(layoutParams.bottomToBottom);
                                    if (targetWidget2 != null) {
                                        viewWidget2.immediateConnect(Type.BOTTOM, targetWidget2, Type.BOTTOM, layoutParams.bottomMargin, layoutParams.goneBottomMargin);
                                    }
                                }
                                if (layoutParams.baselineToBaseline != -1) {
                                    View view = (View) this.mChildrenByIds.get(layoutParams.baselineToBaseline);
                                    viewWidget = getTargetWidget(layoutParams.baselineToBaseline);
                                    if (!(viewWidget == null || view == null || !(view.getLayoutParams() instanceof LayoutParams))) {
                                        LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                                        layoutParams.needsBaseline = true;
                                        layoutParams2.needsBaseline = true;
                                        viewWidget2.getAnchor(Type.BASELINE).connect(viewWidget.getAnchor(Type.BASELINE), 0, -1, Strength.STRONG, 0, true);
                                        viewWidget2.getAnchor(Type.TOP).reset();
                                        viewWidget2.getAnchor(Type.BOTTOM).reset();
                                    }
                                }
                                f2 = f4;
                                if (f2 >= 0.0f && f2 != 0.5f) {
                                    viewWidget2.setHorizontalBiasPercent(f2);
                                }
                                if (layoutParams.verticalBias >= 0.0f && layoutParams.verticalBias != 0.5f) {
                                    viewWidget2.setVerticalBiasPercent(layoutParams.verticalBias);
                                }
                            }
                            if (isInEditMode && !(layoutParams.editorAbsoluteX == -1 && layoutParams.editorAbsoluteY == -1)) {
                                viewWidget2.setOrigin(layoutParams.editorAbsoluteX, layoutParams.editorAbsoluteY);
                            }
                            if (layoutParams.horizontalDimensionFixed) {
                                viewWidget2.setHorizontalDimensionBehaviour(DimensionBehaviour.FIXED);
                                viewWidget2.setWidth(layoutParams.width);
                            } else if (layoutParams.width == -1) {
                                viewWidget2.setHorizontalDimensionBehaviour(DimensionBehaviour.MATCH_PARENT);
                                viewWidget2.getAnchor(Type.LEFT).mMargin = layoutParams.leftMargin;
                                viewWidget2.getAnchor(Type.RIGHT).mMargin = layoutParams.rightMargin;
                            } else {
                                viewWidget2.setHorizontalDimensionBehaviour(DimensionBehaviour.MATCH_CONSTRAINT);
                                viewWidget2.setWidth(0);
                            }
                            if (layoutParams.verticalDimensionFixed) {
                                z = false;
                                viewWidget2.setVerticalDimensionBehaviour(DimensionBehaviour.FIXED);
                                viewWidget2.setHeight(layoutParams.height);
                            } else if (layoutParams.height == -1) {
                                viewWidget2.setVerticalDimensionBehaviour(DimensionBehaviour.MATCH_PARENT);
                                viewWidget2.getAnchor(Type.TOP).mMargin = layoutParams.topMargin;
                                viewWidget2.getAnchor(Type.BOTTOM).mMargin = layoutParams.bottomMargin;
                                z = false;
                            } else {
                                viewWidget2.setVerticalDimensionBehaviour(DimensionBehaviour.MATCH_CONSTRAINT);
                                z = false;
                                viewWidget2.setHeight(0);
                            }
                            if (layoutParams.dimensionRatio != null) {
                                viewWidget2.setDimensionRatio(layoutParams.dimensionRatio);
                            }
                            viewWidget2.setHorizontalWeight(layoutParams.horizontalWeight);
                            viewWidget2.setVerticalWeight(layoutParams.verticalWeight);
                            viewWidget2.setHorizontalChainStyle(layoutParams.horizontalChainStyle);
                            viewWidget2.setVerticalChainStyle(layoutParams.verticalChainStyle);
                            viewWidget2.setHorizontalMatchStyle(layoutParams.matchConstraintDefaultWidth, layoutParams.matchConstraintMinWidth, layoutParams.matchConstraintMaxWidth, layoutParams.matchConstraintPercentWidth);
                            viewWidget2.setVerticalMatchStyle(layoutParams.matchConstraintDefaultHeight, layoutParams.matchConstraintMinHeight, layoutParams.matchConstraintMaxHeight, layoutParams.matchConstraintPercentHeight);
                        }
                    }
                }
            }
        }
    }

    private final ConstraintWidget getTargetWidget(int i) {
        if (i == 0) {
            return this.mLayoutWidget;
        }
        View view = (View) this.mChildrenByIds.get(i);
        if (view == null) {
            view = findViewById(i);
            if (!(view == null || view == this || view.getParent() != this)) {
                onViewAdded(view);
            }
        }
        if (view == this) {
            return this.mLayoutWidget;
        }
        ConstraintWidget constraintWidget;
        if (view == null) {
            constraintWidget = null;
        } else {
            constraintWidget = ((LayoutParams) view.getLayoutParams()).widget;
        }
        return constraintWidget;
    }

    public final ConstraintWidget getViewWidget(View view) {
        if (view == this) {
            return this.mLayoutWidget;
        }
        ConstraintWidget constraintWidget;
        if (view == null) {
            constraintWidget = null;
        } else {
            constraintWidget = ((LayoutParams) view.getLayoutParams()).widget;
        }
        return constraintWidget;
    }

    private void internalMeasureChildren(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                ConstraintWidget constraintWidget = layoutParams.widget;
                if (!(layoutParams.isGuideline || layoutParams.isHelper)) {
                    int childMeasureSpec;
                    Object obj;
                    Object obj2;
                    constraintWidget.setVisibility(childAt.getVisibility());
                    int i6 = layoutParams.width;
                    int i7 = layoutParams.height;
                    Object obj3 = (layoutParams.horizontalDimensionFixed || layoutParams.verticalDimensionFixed || ((!layoutParams.horizontalDimensionFixed && layoutParams.matchConstraintDefaultWidth == 1) || layoutParams.width == -1 || (!layoutParams.verticalDimensionFixed && (layoutParams.matchConstraintDefaultHeight == 1 || layoutParams.height == -1)))) ? 1 : null;
                    if (obj3 != null) {
                        int childMeasureSpec2;
                        if (i6 == 0) {
                            childMeasureSpec = getChildMeasureSpec(i3, paddingLeft, -2);
                            obj = 1;
                        } else if (i6 == -1) {
                            childMeasureSpec = getChildMeasureSpec(i3, paddingLeft, -1);
                            obj = null;
                        } else {
                            obj = i6 == -2 ? 1 : null;
                            childMeasureSpec = getChildMeasureSpec(i3, paddingLeft, i6);
                        }
                        if (i7 == 0) {
                            obj2 = 1;
                            childMeasureSpec2 = getChildMeasureSpec(i4, paddingTop, -2);
                        } else if (i7 == -1) {
                            childMeasureSpec2 = getChildMeasureSpec(i4, paddingTop, -1);
                            obj2 = null;
                        } else {
                            obj2 = i7 == -2 ? 1 : null;
                            childMeasureSpec2 = getChildMeasureSpec(i4, paddingTop, i7);
                        }
                        childAt.measure(childMeasureSpec, childMeasureSpec2);
                        Metrics metrics = this.mMetrics;
                        if (metrics != null) {
                            metrics.measures++;
                        }
                        constraintWidget.setWidthWrapContent(i6 == -2);
                        constraintWidget.setHeightWrapContent(i7 == -2);
                        i6 = childAt.getMeasuredWidth();
                        i7 = childAt.getMeasuredHeight();
                    } else {
                        obj = null;
                        obj2 = null;
                    }
                    constraintWidget.setWidth(i6);
                    constraintWidget.setHeight(i7);
                    if (obj != null) {
                        constraintWidget.setWrapWidth(i6);
                    }
                    if (obj2 != null) {
                        constraintWidget.setWrapHeight(i7);
                    }
                    if (layoutParams.needsBaseline) {
                        childMeasureSpec = childAt.getBaseline();
                        if (childMeasureSpec != -1) {
                            constraintWidget.setBaselineDistance(childMeasureSpec);
                        }
                    }
                }
            }
        }
    }

    private void updatePostMeasures() {
        int childCount = getChildCount();
        int i = 0;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt instanceof Placeholder) {
                ((Placeholder) childAt).updatePostMeasure(this);
            }
        }
        childCount = this.mConstraintHelpers.size();
        if (childCount > 0) {
            while (i < childCount) {
                ((ConstraintHelper) this.mConstraintHelpers.get(i)).updatePostMeasure(this);
                i++;
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:130:0x026e  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0265  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x0275  */
    /* JADX WARNING: Removed duplicated region for block: B:133:0x0273  */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x027d  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x027b  */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x0291  */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x0296  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x02a3  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x02b4  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x02ac  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x02cc  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x02c1  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0265  */
    /* JADX WARNING: Removed duplicated region for block: B:130:0x026e  */
    /* JADX WARNING: Removed duplicated region for block: B:133:0x0273  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x0275  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x027b  */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x027d  */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x0291  */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x0296  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x02a3  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x02ac  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x02b4  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x02c1  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x02cc  */
    /* JADX WARNING: Removed duplicated region for block: B:119:0x0240  */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x0206  */
    /* JADX WARNING: Removed duplicated region for block: B:130:0x026e  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0265  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x0275  */
    /* JADX WARNING: Removed duplicated region for block: B:133:0x0273  */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x027d  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x027b  */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x0291  */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x0296  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x02a3  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x02b4  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x02ac  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x02cc  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x02c1  */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x0206  */
    /* JADX WARNING: Removed duplicated region for block: B:119:0x0240  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0265  */
    /* JADX WARNING: Removed duplicated region for block: B:130:0x026e  */
    /* JADX WARNING: Removed duplicated region for block: B:133:0x0273  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x0275  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x027b  */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x027d  */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x0291  */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x0296  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x02a3  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x02ac  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x02b4  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x02c1  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x02cc  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void internalMeasureDimensions(int i, int i2) {
        long j;
        int i3;
        int i4;
        int i5;
        int childMeasureSpec;
        ConstraintLayout constraintLayout = this;
        int i6 = i;
        int i7 = i2;
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int childCount = getChildCount();
        int i8 = 0;
        while (true) {
            j = 1;
            i3 = 8;
            if (i8 >= childCount) {
                break;
            }
            View childAt = constraintLayout.getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                ConstraintWidget constraintWidget = layoutParams.widget;
                if (!(layoutParams.isGuideline || layoutParams.isHelper)) {
                    constraintWidget.setVisibility(childAt.getVisibility());
                    int i9 = layoutParams.width;
                    i4 = layoutParams.height;
                    if (i9 == 0 || i4 == 0) {
                        i5 = paddingTop;
                        constraintWidget.getResolutionWidth().invalidate();
                        constraintWidget.getResolutionHeight().invalidate();
                        i8++;
                        i7 = i2;
                        paddingTop = i5;
                    } else {
                        Object obj = i9 == -2 ? 1 : null;
                        childMeasureSpec = getChildMeasureSpec(i6, paddingLeft, i9);
                        Object obj2 = i4 == -2 ? 1 : null;
                        childAt.measure(childMeasureSpec, getChildMeasureSpec(i7, paddingTop, i4));
                        Metrics metrics = constraintLayout.mMetrics;
                        if (metrics != null) {
                            i5 = paddingTop;
                            metrics.measures++;
                        } else {
                            i5 = paddingTop;
                        }
                        constraintWidget.setWidthWrapContent(i9 == -2);
                        constraintWidget.setHeightWrapContent(i4 == -2);
                        i7 = childAt.getMeasuredWidth();
                        paddingTop = childAt.getMeasuredHeight();
                        constraintWidget.setWidth(i7);
                        constraintWidget.setHeight(paddingTop);
                        if (obj != null) {
                            constraintWidget.setWrapWidth(i7);
                        }
                        if (obj2 != null) {
                            constraintWidget.setWrapHeight(paddingTop);
                        }
                        if (layoutParams.needsBaseline) {
                            i9 = childAt.getBaseline();
                            if (i9 != -1) {
                                constraintWidget.setBaselineDistance(i9);
                            }
                        }
                        if (layoutParams.horizontalDimensionFixed && layoutParams.verticalDimensionFixed) {
                            constraintWidget.getResolutionWidth().resolve(i7);
                            constraintWidget.getResolutionHeight().resolve(paddingTop);
                        }
                        i8++;
                        i7 = i2;
                        paddingTop = i5;
                    }
                }
            }
            i5 = paddingTop;
            i8++;
            i7 = i2;
            paddingTop = i5;
        }
        i5 = paddingTop;
        constraintLayout.mLayoutWidget.solveGraph();
        i7 = 0;
        while (i7 < childCount) {
            int i10;
            int i11;
            long j2;
            View childAt2 = constraintLayout.getChildAt(i7);
            if (childAt2.getVisibility() != i3) {
                LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                ConstraintWidget constraintWidget2 = layoutParams2.widget;
                if (!(layoutParams2.isGuideline || layoutParams2.isHelper)) {
                    constraintWidget2.setVisibility(childAt2.getVisibility());
                    childMeasureSpec = layoutParams2.width;
                    i4 = layoutParams2.height;
                    if (childMeasureSpec == 0 || i4 == 0) {
                        ResolutionAnchor resolutionNode = constraintWidget2.getAnchor(Type.LEFT).getResolutionNode();
                        ResolutionAnchor resolutionNode2 = constraintWidget2.getAnchor(Type.RIGHT).getResolutionNode();
                        Object obj3 = (constraintWidget2.getAnchor(Type.LEFT).getTarget() == null || constraintWidget2.getAnchor(Type.RIGHT).getTarget() == null) ? null : 1;
                        ResolutionAnchor resolutionNode3 = constraintWidget2.getAnchor(Type.TOP).getResolutionNode();
                        ResolutionAnchor resolutionNode4 = constraintWidget2.getAnchor(Type.BOTTOM).getResolutionNode();
                        i10 = childCount;
                        Object obj4 = (constraintWidget2.getAnchor(Type.TOP).getTarget() == null || constraintWidget2.getAnchor(Type.BOTTOM).getTarget() == null) ? null : 1;
                        if (childMeasureSpec != 0 || i4 != 0 || obj3 == null || obj4 == null) {
                            int childMeasureSpec2;
                            Object obj5;
                            Object obj6;
                            int childMeasureSpec3;
                            Object obj7;
                            Metrics metrics2;
                            i11 = i7;
                            LayoutParams layoutParams3 = layoutParams2;
                            Object obj8 = constraintLayout.mLayoutWidget.getHorizontalDimensionBehaviour() != DimensionBehaviour.WRAP_CONTENT ? 1 : null;
                            Object obj9 = constraintLayout.mLayoutWidget.getVerticalDimensionBehaviour() != DimensionBehaviour.WRAP_CONTENT ? 1 : null;
                            if (obj8 == null) {
                                constraintWidget2.getResolutionWidth().invalidate();
                            }
                            if (obj9 == null) {
                                constraintWidget2.getResolutionHeight().invalidate();
                            }
                            if (childMeasureSpec == 0) {
                                if (obj8 != null && constraintWidget2.isSpreadWidth() && obj3 != null && resolutionNode.isResolved() && resolutionNode2.isResolved()) {
                                    childMeasureSpec = (int) (resolutionNode2.getResolvedValue() - resolutionNode.getResolvedValue());
                                    constraintWidget2.getResolutionWidth().resolve(childMeasureSpec);
                                    childMeasureSpec2 = getChildMeasureSpec(i6, paddingLeft, childMeasureSpec);
                                } else {
                                    childMeasureSpec2 = getChildMeasureSpec(i6, paddingLeft, -2);
                                    obj5 = 1;
                                    obj8 = null;
                                    if (i4 != 0) {
                                        childCount = i2;
                                        if (i4 == -1) {
                                            obj6 = obj9;
                                            childMeasureSpec3 = getChildMeasureSpec(childCount, i5, -1);
                                        } else {
                                            obj7 = i4 == -2 ? 1 : null;
                                            obj6 = obj9;
                                            childMeasureSpec3 = getChildMeasureSpec(childCount, i5, i4);
                                            childAt2.measure(childMeasureSpec2, childMeasureSpec3);
                                            constraintLayout = this;
                                            metrics2 = constraintLayout.mMetrics;
                                            if (metrics2 != null) {
                                            }
                                            if (childMeasureSpec == -2) {
                                            }
                                            constraintWidget2.setWidthWrapContent(childMeasureSpec == -2);
                                            if (i4 == -2) {
                                            }
                                            constraintWidget2.setHeightWrapContent(i4 == -2);
                                            childMeasureSpec = childAt2.getMeasuredWidth();
                                            i4 = childAt2.getMeasuredHeight();
                                            constraintWidget2.setWidth(childMeasureSpec);
                                            constraintWidget2.setHeight(i4);
                                            if (obj5 != null) {
                                            }
                                            if (obj7 != null) {
                                            }
                                            if (obj8 != null) {
                                            }
                                            if (obj6 != null) {
                                            }
                                            if (layoutParams3.needsBaseline) {
                                            }
                                            i7 = i11 + 1;
                                            childCount = i10;
                                            j = j2;
                                            i3 = 8;
                                        }
                                    } else if (obj9 != null && constraintWidget2.isSpreadHeight() && obj4 != null && resolutionNode3.isResolved() && resolutionNode4.isResolved()) {
                                        i4 = (int) (resolutionNode4.getResolvedValue() - resolutionNode3.getResolvedValue());
                                        constraintWidget2.getResolutionHeight().resolve(i4);
                                        obj6 = obj9;
                                        childMeasureSpec3 = getChildMeasureSpec(i2, i5, i4);
                                    } else {
                                        childMeasureSpec3 = getChildMeasureSpec(i2, i5, -2);
                                        obj7 = 1;
                                        obj6 = null;
                                        childAt2.measure(childMeasureSpec2, childMeasureSpec3);
                                        constraintLayout = this;
                                        metrics2 = constraintLayout.mMetrics;
                                        if (metrics2 != null) {
                                            j2 = 1;
                                            metrics2.measures++;
                                        } else {
                                            j2 = 1;
                                        }
                                        constraintWidget2.setWidthWrapContent(childMeasureSpec == -2);
                                        constraintWidget2.setHeightWrapContent(i4 == -2);
                                        childMeasureSpec = childAt2.getMeasuredWidth();
                                        i4 = childAt2.getMeasuredHeight();
                                        constraintWidget2.setWidth(childMeasureSpec);
                                        constraintWidget2.setHeight(i4);
                                        if (obj5 != null) {
                                            constraintWidget2.setWrapWidth(childMeasureSpec);
                                        }
                                        if (obj7 != null) {
                                            constraintWidget2.setWrapHeight(i4);
                                        }
                                        if (obj8 != null) {
                                            constraintWidget2.getResolutionWidth().resolve(childMeasureSpec);
                                        } else {
                                            constraintWidget2.getResolutionWidth().remove();
                                        }
                                        if (obj6 != null) {
                                            constraintWidget2.getResolutionHeight().resolve(i4);
                                        } else {
                                            constraintWidget2.getResolutionHeight().remove();
                                        }
                                        if (layoutParams3.needsBaseline) {
                                            i7 = childAt2.getBaseline();
                                            if (i7 != -1) {
                                                constraintWidget2.setBaselineDistance(i7);
                                            }
                                        }
                                        i7 = i11 + 1;
                                        childCount = i10;
                                        j = j2;
                                        i3 = 8;
                                    }
                                    obj7 = null;
                                    childAt2.measure(childMeasureSpec2, childMeasureSpec3);
                                    constraintLayout = this;
                                    metrics2 = constraintLayout.mMetrics;
                                    if (metrics2 != null) {
                                    }
                                    if (childMeasureSpec == -2) {
                                    }
                                    constraintWidget2.setWidthWrapContent(childMeasureSpec == -2);
                                    if (i4 == -2) {
                                    }
                                    constraintWidget2.setHeightWrapContent(i4 == -2);
                                    childMeasureSpec = childAt2.getMeasuredWidth();
                                    i4 = childAt2.getMeasuredHeight();
                                    constraintWidget2.setWidth(childMeasureSpec);
                                    constraintWidget2.setHeight(i4);
                                    if (obj5 != null) {
                                    }
                                    if (obj7 != null) {
                                    }
                                    if (obj8 != null) {
                                    }
                                    if (obj6 != null) {
                                    }
                                    if (layoutParams3.needsBaseline) {
                                    }
                                    i7 = i11 + 1;
                                    childCount = i10;
                                    j = j2;
                                    i3 = 8;
                                }
                            } else if (childMeasureSpec == -1) {
                                childMeasureSpec2 = getChildMeasureSpec(i6, paddingLeft, -1);
                            } else {
                                obj5 = childMeasureSpec == -2 ? 1 : null;
                                childMeasureSpec2 = getChildMeasureSpec(i6, paddingLeft, childMeasureSpec);
                                if (i4 != 0) {
                                }
                                obj7 = null;
                                childAt2.measure(childMeasureSpec2, childMeasureSpec3);
                                constraintLayout = this;
                                metrics2 = constraintLayout.mMetrics;
                                if (metrics2 != null) {
                                }
                                if (childMeasureSpec == -2) {
                                }
                                constraintWidget2.setWidthWrapContent(childMeasureSpec == -2);
                                if (i4 == -2) {
                                }
                                constraintWidget2.setHeightWrapContent(i4 == -2);
                                childMeasureSpec = childAt2.getMeasuredWidth();
                                i4 = childAt2.getMeasuredHeight();
                                constraintWidget2.setWidth(childMeasureSpec);
                                constraintWidget2.setHeight(i4);
                                if (obj5 != null) {
                                }
                                if (obj7 != null) {
                                }
                                if (obj8 != null) {
                                }
                                if (obj6 != null) {
                                }
                                if (layoutParams3.needsBaseline) {
                                }
                                i7 = i11 + 1;
                                childCount = i10;
                                j = j2;
                                i3 = 8;
                            }
                            obj5 = null;
                            if (i4 != 0) {
                            }
                            obj7 = null;
                            childAt2.measure(childMeasureSpec2, childMeasureSpec3);
                            constraintLayout = this;
                            metrics2 = constraintLayout.mMetrics;
                            if (metrics2 != null) {
                            }
                            if (childMeasureSpec == -2) {
                            }
                            constraintWidget2.setWidthWrapContent(childMeasureSpec == -2);
                            if (i4 == -2) {
                            }
                            constraintWidget2.setHeightWrapContent(i4 == -2);
                            childMeasureSpec = childAt2.getMeasuredWidth();
                            i4 = childAt2.getMeasuredHeight();
                            constraintWidget2.setWidth(childMeasureSpec);
                            constraintWidget2.setHeight(i4);
                            if (obj5 != null) {
                            }
                            if (obj7 != null) {
                            }
                            if (obj8 != null) {
                            }
                            if (obj6 != null) {
                            }
                            if (layoutParams3.needsBaseline) {
                            }
                            i7 = i11 + 1;
                            childCount = i10;
                            j = j2;
                            i3 = 8;
                        } else {
                            childCount = i2;
                            i11 = i7;
                            j2 = 1;
                            i7 = i11 + 1;
                            childCount = i10;
                            j = j2;
                            i3 = 8;
                        }
                    }
                }
            }
            i11 = i7;
            i10 = childCount;
            j2 = j;
            childCount = i2;
            i7 = i11 + 1;
            childCount = i10;
            j = j2;
            i3 = 8;
        }
    }

    public void fillMetrics(Metrics metrics) {
        this.mMetrics = metrics;
        this.mLayoutWidget.fillMetrics(metrics);
    }

    /* JADX WARNING: Removed duplicated region for block: B:62:0x013a  */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x0371  */
    /* JADX WARNING: Removed duplicated region for block: B:65:0x0151  */
    /* JADX WARNING: Removed duplicated region for block: B:180:0x03bf  */
    /* JADX WARNING: Removed duplicated region for block: B:173:0x0386  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void onMeasure(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        System.currentTimeMillis();
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size2 = MeasureSpec.getSize(i2);
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        this.mLayoutWidget.setX(paddingLeft);
        this.mLayoutWidget.setY(paddingTop);
        this.mLayoutWidget.setMaxWidth(this.mMaxWidth);
        this.mLayoutWidget.setMaxHeight(this.mMaxHeight);
        boolean z = false;
        if (VERSION.SDK_INT >= 17) {
            this.mLayoutWidget.setRtl(getLayoutDirection() == 1);
        }
        setSelfDimensionBehaviour(i, i2);
        int width = this.mLayoutWidget.getWidth();
        int height = this.mLayoutWidget.getHeight();
        boolean z2;
        if (this.mDirtyHierarchy) {
            this.mDirtyHierarchy = false;
            updateHierarchy();
            z2 = true;
        } else {
            z2 = false;
        }
        boolean z3 = (this.mOptimizationLevel & 8) == 8;
        if (z3) {
            this.mLayoutWidget.preOptimize();
            this.mLayoutWidget.optimizeForDimensions(width, height);
            internalMeasureDimensions(i, i2);
        } else {
            internalMeasureChildren(i, i2);
        }
        updatePostMeasures();
        if (getChildCount() > 0 && z2) {
            Analyzer.determineGroups(this.mLayoutWidget);
        }
        if (this.mLayoutWidget.mGroupsWrapOptimized) {
            if (this.mLayoutWidget.mHorizontalWrapOptimized && mode == Integer.MIN_VALUE) {
                if (this.mLayoutWidget.mWrapFixedWidth < size) {
                    ConstraintWidgetContainer constraintWidgetContainer = this.mLayoutWidget;
                    constraintWidgetContainer.setWidth(constraintWidgetContainer.mWrapFixedWidth);
                }
                this.mLayoutWidget.setHorizontalDimensionBehaviour(DimensionBehaviour.FIXED);
            }
            if (this.mLayoutWidget.mVerticalWrapOptimized && mode2 == Integer.MIN_VALUE) {
                if (this.mLayoutWidget.mWrapFixedHeight < size2) {
                    ConstraintWidgetContainer constraintWidgetContainer2 = this.mLayoutWidget;
                    constraintWidgetContainer2.setHeight(constraintWidgetContainer2.mWrapFixedHeight);
                }
                this.mLayoutWidget.setVerticalDimensionBehaviour(DimensionBehaviour.FIXED);
            }
        }
        if ((this.mOptimizationLevel & 32) == 32) {
            int width2 = this.mLayoutWidget.getWidth();
            int height2 = this.mLayoutWidget.getHeight();
            if (this.mLastMeasureWidth != width2 && mode == 1073741824) {
                Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, width2);
            }
            if (this.mLastMeasureHeight != height2 && mode2 == 1073741824) {
                Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, height2);
            }
            if (!this.mLayoutWidget.mHorizontalWrapOptimized || this.mLayoutWidget.mWrapFixedWidth <= size) {
                z = false;
            } else {
                z = false;
                Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 0, size);
            }
            if (this.mLayoutWidget.mVerticalWrapOptimized && this.mLayoutWidget.mWrapFixedHeight > size2) {
                size = 1;
                Analyzer.setPosition(this.mLayoutWidget.mWidgetGroups, 1, size2);
                if (getChildCount() > 0) {
                    solveLinearSystem("First pass");
                }
                mode = this.mVariableDimensionsWidgets.size();
                paddingTop += getPaddingBottom();
                paddingLeft += getPaddingRight();
                if (mode <= 0) {
                    int i5;
                    int i6;
                    int i7;
                    size2 = this.mLayoutWidget.getHorizontalDimensionBehaviour() == DimensionBehaviour.WRAP_CONTENT ? size : z;
                    width2 = this.mLayoutWidget.getVerticalDimensionBehaviour() == DimensionBehaviour.WRAP_CONTENT ? size : z;
                    height2 = Math.max(this.mLayoutWidget.getWidth(), this.mMinWidth);
                    mode2 = Math.max(this.mLayoutWidget.getHeight(), this.mMinHeight);
                    size = 0;
                    Object obj = null;
                    int i8 = 0;
                    while (size < mode) {
                        Object obj2;
                        ConstraintWidget constraintWidget = (ConstraintWidget) this.mVariableDimensionsWidgets.get(size);
                        i5 = mode;
                        View view = (View) constraintWidget.getCompanionWidget();
                        if (view == null) {
                            i6 = width;
                            obj2 = obj;
                            i7 = height;
                        } else {
                            i7 = height;
                            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
                            i6 = width;
                            if (layoutParams.isHelper || layoutParams.isGuideline) {
                                obj2 = obj;
                            } else {
                                obj2 = obj;
                                if (!(view.getVisibility() == 8 || (z3 && constraintWidget.getResolutionWidth().isResolved() && constraintWidget.getResolutionHeight().isResolved()))) {
                                    if (layoutParams.width == -2 && layoutParams.horizontalDimensionFixed) {
                                        width = getChildMeasureSpec(i3, paddingLeft, layoutParams.width);
                                    } else {
                                        width = MeasureSpec.makeMeasureSpec(constraintWidget.getWidth(), 1073741824);
                                    }
                                    if (layoutParams.height == -2 && layoutParams.verticalDimensionFixed) {
                                        i3 = getChildMeasureSpec(i4, paddingTop, layoutParams.height);
                                    } else {
                                        i3 = MeasureSpec.makeMeasureSpec(constraintWidget.getHeight(), 1073741824);
                                    }
                                    view.measure(width, i3);
                                    Metrics metrics = this.mMetrics;
                                    if (metrics != null) {
                                        metrics.additionalMeasures++;
                                    }
                                    i3 = view.getMeasuredWidth();
                                    width = view.getMeasuredHeight();
                                    if (i3 != constraintWidget.getWidth()) {
                                        constraintWidget.setWidth(i3);
                                        if (z3) {
                                            constraintWidget.getResolutionWidth().resolve(i3);
                                        }
                                        if (size2 != 0 && constraintWidget.getRight() > height2) {
                                            height2 = Math.max(height2, constraintWidget.getRight() + constraintWidget.getAnchor(Type.RIGHT).getMargin());
                                        }
                                        obj2 = 1;
                                    }
                                    if (width != constraintWidget.getHeight()) {
                                        constraintWidget.setHeight(width);
                                        if (z3) {
                                            constraintWidget.getResolutionHeight().resolve(width);
                                        }
                                        if (width2 != 0 && constraintWidget.getBottom() > mode2) {
                                            mode2 = Math.max(mode2, constraintWidget.getBottom() + constraintWidget.getAnchor(Type.BOTTOM).getMargin());
                                        }
                                        obj2 = 1;
                                    }
                                    if (layoutParams.needsBaseline) {
                                        i3 = view.getBaseline();
                                        if (!(i3 == -1 || i3 == constraintWidget.getBaselineDistance())) {
                                            constraintWidget.setBaselineDistance(i3);
                                            obj2 = 1;
                                        }
                                    }
                                    if (VERSION.SDK_INT >= 11) {
                                        i8 = combineMeasuredStates(i8, view.getMeasuredState());
                                    } else {
                                        mode = i8;
                                    }
                                    obj = obj2;
                                    size++;
                                    i3 = i;
                                    width = i6;
                                    mode = i5;
                                    height = i7;
                                }
                            }
                        }
                        i8 = i8;
                        obj = obj2;
                        size++;
                        i3 = i;
                        width = i6;
                        mode = i5;
                        height = i7;
                    }
                    i5 = mode;
                    i6 = width;
                    i7 = height;
                    mode = i8;
                    if (obj != null) {
                        Object obj3;
                        Object obj4;
                        this.mLayoutWidget.setWidth(i6);
                        this.mLayoutWidget.setHeight(i7);
                        if (z3) {
                            this.mLayoutWidget.solveGraph();
                        }
                        solveLinearSystem("2nd pass");
                        if (this.mLayoutWidget.getWidth() < height2) {
                            this.mLayoutWidget.setWidth(height2);
                            obj3 = 1;
                        } else {
                            obj3 = null;
                        }
                        if (this.mLayoutWidget.getHeight() < mode2) {
                            this.mLayoutWidget.setHeight(mode2);
                            obj4 = 1;
                        } else {
                            obj4 = obj3;
                        }
                        if (obj4 != null) {
                            solveLinearSystem("3rd pass");
                        }
                    }
                    i3 = i5;
                    for (size = 0; size < i3; size++) {
                        ConstraintWidget constraintWidget2 = (ConstraintWidget) this.mVariableDimensionsWidgets.get(size);
                        View view2 = (View) constraintWidget2.getCompanionWidget();
                        if (view2 != null && (view2.getMeasuredWidth() != constraintWidget2.getWidth() || view2.getMeasuredHeight() != constraintWidget2.getHeight())) {
                            if (constraintWidget2.getVisibility() != 8) {
                                view2.measure(MeasureSpec.makeMeasureSpec(constraintWidget2.getWidth(), 1073741824), MeasureSpec.makeMeasureSpec(constraintWidget2.getHeight(), 1073741824));
                                Metrics metrics2 = this.mMetrics;
                                if (metrics2 != null) {
                                    metrics2.additionalMeasures++;
                                }
                            }
                        }
                    }
                } else {
                    mode = 0;
                }
                i3 = this.mLayoutWidget.getWidth() + paddingLeft;
                size = this.mLayoutWidget.getHeight() + paddingTop;
                if (VERSION.SDK_INT < 11) {
                    i4 = resolveSizeAndState(size, i4, mode << 16) & 16777215;
                    i3 = Math.min(this.mMaxWidth, resolveSizeAndState(i3, i, mode) & 16777215);
                    i4 = Math.min(this.mMaxHeight, i4);
                    if (this.mLayoutWidget.isWidthMeasuredTooSmall()) {
                        i3 |= 16777216;
                    }
                    if (this.mLayoutWidget.isHeightMeasuredTooSmall()) {
                        i4 |= 16777216;
                    }
                    setMeasuredDimension(i3, i4);
                    this.mLastMeasureWidth = i3;
                    this.mLastMeasureHeight = i4;
                    return;
                }
                setMeasuredDimension(i3, size);
                this.mLastMeasureWidth = i3;
                this.mLastMeasureHeight = size;
                return;
            }
        }
        size = 1;
        if (getChildCount() > 0) {
        }
        mode = this.mVariableDimensionsWidgets.size();
        paddingTop += getPaddingBottom();
        paddingLeft += getPaddingRight();
        if (mode <= 0) {
        }
        i3 = this.mLayoutWidget.getWidth() + paddingLeft;
        size = this.mLayoutWidget.getHeight() + paddingTop;
        if (VERSION.SDK_INT < 11) {
        }
    }

    private void setSelfDimensionBehaviour(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        i = MeasureSpec.getSize(i);
        int mode2 = MeasureSpec.getMode(i2);
        i2 = MeasureSpec.getSize(i2);
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        DimensionBehaviour dimensionBehaviour = DimensionBehaviour.FIXED;
        DimensionBehaviour dimensionBehaviour2 = DimensionBehaviour.FIXED;
        getLayoutParams();
        if (mode != Integer.MIN_VALUE) {
            if (mode == 0) {
                dimensionBehaviour = DimensionBehaviour.WRAP_CONTENT;
            } else if (mode == 1073741824) {
                i = Math.min(this.mMaxWidth, i) - paddingLeft;
            }
            i = 0;
        } else {
            dimensionBehaviour = DimensionBehaviour.WRAP_CONTENT;
        }
        if (mode2 != Integer.MIN_VALUE) {
            if (mode2 == 0) {
                dimensionBehaviour2 = DimensionBehaviour.WRAP_CONTENT;
            } else if (mode2 == 1073741824) {
                i2 = Math.min(this.mMaxHeight, i2) - paddingTop;
            }
            i2 = 0;
        } else {
            dimensionBehaviour2 = DimensionBehaviour.WRAP_CONTENT;
        }
        this.mLayoutWidget.setMinWidth(0);
        this.mLayoutWidget.setMinHeight(0);
        this.mLayoutWidget.setHorizontalDimensionBehaviour(dimensionBehaviour);
        this.mLayoutWidget.setWidth(i);
        this.mLayoutWidget.setVerticalDimensionBehaviour(dimensionBehaviour2);
        this.mLayoutWidget.setHeight(i2);
        this.mLayoutWidget.setMinWidth((this.mMinWidth - getPaddingLeft()) - getPaddingRight());
        this.mLayoutWidget.setMinHeight((this.mMinHeight - getPaddingTop()) - getPaddingBottom());
    }

    protected void solveLinearSystem(String str) {
        this.mLayoutWidget.layout();
        Metrics metrics = this.mMetrics;
        if (metrics != null) {
            metrics.resolutions++;
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        i2 = 0;
        for (i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            ConstraintWidget constraintWidget = layoutParams.widget;
            if ((childAt.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper || isInEditMode) && !layoutParams.isInPlaceholder) {
                int drawX = constraintWidget.getDrawX();
                int drawY = constraintWidget.getDrawY();
                int width = constraintWidget.getWidth() + drawX;
                int height = constraintWidget.getHeight() + drawY;
                childAt.layout(drawX, drawY, width, height);
                if (childAt instanceof Placeholder) {
                    childAt = ((Placeholder) childAt).getContent();
                    if (childAt != null) {
                        childAt.setVisibility(0);
                        childAt.layout(drawX, drawY, width, height);
                    }
                }
            }
        }
        childCount = this.mConstraintHelpers.size();
        if (childCount > 0) {
            while (i2 < childCount) {
                ((ConstraintHelper) this.mConstraintHelpers.get(i2)).updatePostLayout(this);
                i2++;
            }
        }
    }

    public void setOptimizationLevel(int i) {
        this.mLayoutWidget.setOptimizationLevel(i);
    }

    public int getOptimizationLevel() {
        return this.mLayoutWidget.getOptimizationLevel();
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    protected android.view.ViewGroup.LayoutParams generateLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    protected boolean checkLayoutParams(android.view.ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public void setConstraintSet(ConstraintSet constraintSet) {
        this.mConstraintSet = constraintSet;
    }

    public View getViewById(int i) {
        return (View) this.mChildrenByIds.get(i);
    }

    public void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            int childCount = getChildCount();
            float width = (float) getWidth();
            float height = (float) getHeight();
            for (int i = 0; i < childCount; i++) {
                View childAt = getChildAt(i);
                if (childAt.getVisibility() != 8) {
                    Object tag = childAt.getTag();
                    if (tag != null && (tag instanceof String)) {
                        String[] split = ((String) tag).split(",");
                        if (split.length == 4) {
                            int parseInt = Integer.parseInt(split[0]);
                            int parseInt2 = Integer.parseInt(split[1]);
                            parseInt = (int) ((((float) parseInt) / 1080.0f) * width);
                            parseInt2 = (int) ((((float) parseInt2) / 1920.0f) * height);
                            int parseInt3 = (int) ((((float) Integer.parseInt(split[2])) / 1080.0f) * width);
                            int parseInt4 = (int) ((((float) Integer.parseInt(split[3])) / 1920.0f) * height);
                            Paint paint = new Paint();
                            paint.setColor(-65536);
                            float f = (float) parseInt;
                            float f2 = (float) (parseInt + parseInt3);
                            Canvas canvas2 = canvas;
                            float f3 = (float) parseInt2;
                            float f4 = f;
                            float f5 = f;
                            f = f3;
                            Paint paint2 = paint;
                            float f6 = f2;
                            Paint paint3 = paint2;
                            canvas2.drawLine(f4, f, f6, f3, paint3);
                            float f7 = (float) (parseInt2 + parseInt4);
                            f4 = f2;
                            float f8 = f7;
                            canvas2.drawLine(f4, f, f6, f8, paint3);
                            f = f7;
                            f6 = f5;
                            canvas2.drawLine(f4, f, f6, f8, paint3);
                            f4 = f5;
                            canvas2.drawLine(f4, f, f6, f3, paint3);
                            paint = paint2;
                            paint.setColor(-16711936);
                            Paint paint4 = paint;
                            f6 = f2;
                            paint3 = paint4;
                            canvas2.drawLine(f4, f3, f6, f7, paint3);
                            canvas2.drawLine(f4, f7, f6, f3, paint3);
                        }
                    }
                }
            }
        }
    }

    public void requestLayout() {
        super.requestLayout();
        this.mDirtyHierarchy = true;
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
    }
}
