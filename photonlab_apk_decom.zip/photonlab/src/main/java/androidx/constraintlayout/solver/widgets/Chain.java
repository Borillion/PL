package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.ArrayRow;
import androidx.constraintlayout.solver.LinearSystem;
import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.widgets.ConstraintWidget.DimensionBehaviour;
import java.util.ArrayList;

class Chain {
    private static final boolean DEBUG = false;

    Chain() {
    }

    static void applyChainConstraints(ConstraintWidgetContainer constraintWidgetContainer, LinearSystem linearSystem, int i) {
        int i2;
        ChainHead[] chainHeadArr;
        int i3;
        int i4 = 0;
        if (i == 0) {
            i2 = constraintWidgetContainer.mHorizontalChainsSize;
            chainHeadArr = constraintWidgetContainer.mHorizontalChainsArray;
            i3 = i2;
            i2 = 0;
        } else {
            i2 = 2;
            int i5 = constraintWidgetContainer.mVerticalChainsSize;
            i3 = i5;
            chainHeadArr = constraintWidgetContainer.mVerticalChainsArray;
        }
        while (i4 < i3) {
            ChainHead chainHead = chainHeadArr[i4];
            chainHead.define();
            if (!constraintWidgetContainer.optimizeFor(4)) {
                applyChainConstraints(constraintWidgetContainer, linearSystem, i, i2, chainHead);
            } else if (!Optimizer.applyChainOptimized(constraintWidgetContainer, linearSystem, i, i2, chainHead)) {
                applyChainConstraints(constraintWidgetContainer, linearSystem, i, i2, chainHead);
            }
            i4++;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:293:0x0390 A:{SYNTHETIC} */
    /* JADX WARNING: Removed duplicated region for block: B:190:0x038f  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x015b  */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x0179  */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x03b1  */
    /* JADX WARNING: Removed duplicated region for block: B:256:0x04b6  */
    /* JADX WARNING: Removed duplicated region for block: B:251:0x0481  */
    /* JADX WARNING: Removed duplicated region for block: B:266:0x04e0  */
    /* JADX WARNING: Removed duplicated region for block: B:265:0x04db  */
    /* JADX WARNING: Removed duplicated region for block: B:270:0x04eb  */
    /* JADX WARNING: Removed duplicated region for block: B:269:0x04e6  */
    /* JADX WARNING: Removed duplicated region for block: B:272:0x04ef  */
    /* JADX WARNING: Removed duplicated region for block: B:278:0x0501  */
    /* JADX WARNING: Missing block: B:15:0x0035, code:
            if (r2.mHorizontalChainStyle == 2) goto L_0x004a;
     */
    /* JADX WARNING: Missing block: B:25:0x0048, code:
            if (r2.mVerticalChainStyle == 2) goto L_0x004a;
     */
    /* JADX WARNING: Missing block: B:27:0x004c, code:
            r5 = null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void applyChainConstraints(ConstraintWidgetContainer constraintWidgetContainer, LinearSystem linearSystem, int i, int i2, ChainHead chainHead) {
        Object obj;
        Object obj2;
        int i3;
        float f;
        int i4;
        Object obj3;
        ConstraintWidget constraintWidget;
        ConstraintAnchor constraintAnchor;
        int i5;
        ArrayList arrayList;
        ConstraintWidget constraintWidget2;
        SolverVariable solverVariable;
        ConstraintAnchor constraintAnchor2;
        ConstraintAnchor constraintAnchor3;
        SolverVariable solverVariable2;
        int i6;
        Object obj4;
        ConstraintWidget constraintWidget3;
        int i7;
        ConstraintAnchor constraintAnchor4;
        ConstraintAnchor constraintAnchor5;
        SolverVariable solverVariable3;
        ConstraintWidgetContainer constraintWidgetContainer2 = constraintWidgetContainer;
        LinearSystem linearSystem2 = linearSystem;
        ChainHead chainHead2 = chainHead;
        ConstraintWidget constraintWidget4 = chainHead2.mFirst;
        ConstraintWidget constraintWidget5 = chainHead2.mLast;
        ConstraintWidget constraintWidget6 = chainHead2.mFirstVisibleWidget;
        ConstraintWidget constraintWidget7 = chainHead2.mLastVisibleWidget;
        ConstraintWidget constraintWidget8 = chainHead2.mHead;
        float f2 = chainHead2.mTotalWeight;
        ConstraintWidget constraintWidget9 = chainHead2.mFirstMatchConstraintWidget;
        constraintWidget9 = chainHead2.mLastMatchConstraintWidget;
        Object obj5 = constraintWidgetContainer2.mListDimensionBehaviors[i] == DimensionBehaviour.WRAP_CONTENT ? 1 : null;
        if (i == 0) {
            obj = constraintWidget8.mHorizontalChainStyle == 0 ? 1 : null;
            obj2 = constraintWidget8.mHorizontalChainStyle == 1 ? 1 : null;
        } else {
            obj = constraintWidget8.mVerticalChainStyle == 0 ? 1 : null;
            obj2 = constraintWidget8.mVerticalChainStyle == 1 ? 1 : null;
        }
        Object obj6 = 1;
        Object obj7 = obj;
        ConstraintWidget constraintWidget10 = constraintWidget4;
        Object obj8 = obj2;
        obj2 = obj6;
        obj6 = null;
        while (true) {
            ConstraintWidget constraintWidget11 = null;
            if (obj6 != null) {
                break;
            }
            Object obj9;
            ConstraintAnchor constraintAnchor6 = constraintWidget10.mListAnchors[i2];
            int i8 = (obj5 == null && obj2 == null) ? 4 : 1;
            int margin = constraintAnchor6.getMargin();
            if (!(constraintAnchor6.mTarget == null || constraintWidget10 == constraintWidget4)) {
                margin += constraintAnchor6.mTarget.getMargin();
            }
            i3 = margin;
            if (obj2 != null && constraintWidget10 != constraintWidget4 && constraintWidget10 != constraintWidget6) {
                f = f2;
                obj9 = obj6;
                i4 = 6;
            } else if (obj7 == null || obj5 == null) {
                f = f2;
                i4 = i8;
                obj9 = obj6;
            } else {
                f = f2;
                obj9 = obj6;
                i4 = 4;
            }
            if (constraintAnchor6.mTarget != null) {
                if (constraintWidget10 == constraintWidget6) {
                    obj3 = obj7;
                    constraintWidget = constraintWidget8;
                    linearSystem2.addGreaterThan(constraintAnchor6.mSolverVariable, constraintAnchor6.mTarget.mSolverVariable, i3, 5);
                } else {
                    constraintWidget = constraintWidget8;
                    obj3 = obj7;
                    linearSystem2.addGreaterThan(constraintAnchor6.mSolverVariable, constraintAnchor6.mTarget.mSolverVariable, i3, 6);
                }
                linearSystem2.addEquality(constraintAnchor6.mSolverVariable, constraintAnchor6.mTarget.mSolverVariable, i3, i4);
            } else {
                constraintWidget = constraintWidget8;
                obj3 = obj7;
            }
            if (obj5 != null) {
                if (constraintWidget10.getVisibility() == 8 || constraintWidget10.mListDimensionBehaviors[i] != DimensionBehaviour.MATCH_CONSTRAINT) {
                    i3 = 0;
                } else {
                    i3 = 0;
                    linearSystem2.addGreaterThan(constraintWidget10.mListAnchors[i2 + 1].mSolverVariable, constraintWidget10.mListAnchors[i2].mSolverVariable, 0, 5);
                }
                linearSystem2.addGreaterThan(constraintWidget10.mListAnchors[i2].mSolverVariable, constraintWidgetContainer2.mListAnchors[i2].mSolverVariable, i3, 6);
            }
            constraintAnchor = constraintWidget10.mListAnchors[i2 + 1].mTarget;
            if (constraintAnchor != null) {
                constraintWidget8 = constraintAnchor.mOwner;
                if (constraintWidget8.mListAnchors[i2].mTarget != null && constraintWidget8.mListAnchors[i2].mTarget.mOwner == constraintWidget10) {
                    constraintWidget11 = constraintWidget8;
                }
            }
            if (constraintWidget11 != null) {
                constraintWidget10 = constraintWidget11;
                obj6 = obj9;
            } else {
                obj6 = 1;
            }
            f2 = f;
            obj7 = obj3;
            constraintWidget8 = constraintWidget;
        }
        constraintWidget = constraintWidget8;
        f = f2;
        obj3 = obj7;
        if (constraintWidget7 != null) {
            i4 = i2 + 1;
            if (constraintWidget5.mListAnchors[i4].mTarget != null) {
                int i9;
                int i10;
                int i11;
                SolverVariable solverVariable4;
                SolverVariable solverVariable5;
                constraintAnchor = constraintWidget7.mListAnchors[i4];
                linearSystem2.addLowerThan(constraintAnchor.mSolverVariable, constraintWidget5.mListAnchors[i4].mTarget.mSolverVariable, -constraintAnchor.getMargin(), 5);
                if (obj5 != null) {
                    i5 = i2 + 1;
                    linearSystem2.addGreaterThan(constraintWidgetContainer2.mListAnchors[i5].mSolverVariable, constraintWidget5.mListAnchors[i5].mSolverVariable, constraintWidget5.mListAnchors[i5].getMargin(), 6);
                }
                arrayList = chainHead2.mWeightedMatchConstraintsWidgets;
                if (arrayList != null) {
                    i5 = arrayList.size();
                    if (i5 > 1) {
                        float f3 = (!chainHead2.mHasUndefinedWeights || chainHead2.mHasComplexMatchWeights) ? f : (float) chainHead2.mWidgetsMatchCount;
                        float f4 = 0.0f;
                        float f5 = 0.0f;
                        constraintWidget10 = null;
                        i9 = 0;
                        while (i9 < i5) {
                            ArrayList arrayList2;
                            constraintWidget2 = (ConstraintWidget) arrayList.get(i9);
                            f2 = constraintWidget2.mWeight[i];
                            if (f2 < f4) {
                                if (chainHead2.mHasComplexMatchWeights) {
                                    linearSystem2.addEquality(constraintWidget2.mListAnchors[i2 + 1].mSolverVariable, constraintWidget2.mListAnchors[i2].mSolverVariable, 0, 4);
                                    i10 = 0;
                                    arrayList2 = arrayList;
                                    i11 = i5;
                                    i9++;
                                    i5 = i11;
                                    arrayList = arrayList2;
                                    f4 = 0.0f;
                                } else {
                                    f2 = 1.0f;
                                }
                            }
                            if (f2 == 0.0f) {
                                linearSystem2.addEquality(constraintWidget2.mListAnchors[i2 + 1].mSolverVariable, constraintWidget2.mListAnchors[i2].mSolverVariable, 0, 6);
                                arrayList2 = arrayList;
                                i11 = i5;
                                i9++;
                                i5 = i11;
                                arrayList = arrayList2;
                                f4 = 0.0f;
                            } else {
                                if (constraintWidget10 != null) {
                                    solverVariable = constraintWidget10.mListAnchors[i2].mSolverVariable;
                                    i11 = i2 + 1;
                                    solverVariable4 = constraintWidget10.mListAnchors[i11].mSolverVariable;
                                    solverVariable5 = constraintWidget2.mListAnchors[i2].mSolverVariable;
                                    arrayList2 = arrayList;
                                    SolverVariable solverVariable6 = constraintWidget2.mListAnchors[i11].mSolverVariable;
                                    i11 = i5;
                                    ArrayRow createRow = linearSystem.createRow();
                                    createRow.createRowEqualMatchDimensions(f5, f3, f2, solverVariable, solverVariable4, solverVariable5, solverVariable6);
                                    linearSystem2.addConstraint(createRow);
                                } else {
                                    arrayList2 = arrayList;
                                    i11 = i5;
                                }
                                f5 = f2;
                                constraintWidget10 = constraintWidget2;
                                i9++;
                                i5 = i11;
                                arrayList = arrayList2;
                                f4 = 0.0f;
                            }
                        }
                    }
                }
                ConstraintWidget constraintWidget12;
                SolverVariable solverVariable7;
                SolverVariable solverVariable8;
                int margin2;
                int margin3;
                ConstraintAnchor constraintAnchor7;
                int i12;
                if (constraintWidget6 == null && (constraintWidget6 == constraintWidget7 || obj2 != null)) {
                    constraintAnchor2 = constraintWidget4.mListAnchors[i2];
                    i5 = i2 + 1;
                    constraintAnchor3 = constraintWidget5.mListAnchors[i5];
                    solverVariable2 = constraintWidget4.mListAnchors[i2].mTarget != null ? constraintWidget4.mListAnchors[i2].mTarget.mSolverVariable : null;
                    solverVariable = constraintWidget5.mListAnchors[i5].mTarget != null ? constraintWidget5.mListAnchors[i5].mTarget.mSolverVariable : null;
                    if (constraintWidget6 == constraintWidget7) {
                        constraintAnchor2 = constraintWidget6.mListAnchors[i2];
                        constraintAnchor3 = constraintWidget6.mListAnchors[i5];
                    }
                    if (!(solverVariable2 == null || solverVariable == null)) {
                        float f6;
                        if (i == 0) {
                            f6 = constraintWidget.mHorizontalBiasPercent;
                        } else {
                            f6 = constraintWidget.mVerticalBiasPercent;
                        }
                        linearSystem.addCentering(constraintAnchor2.mSolverVariable, solverVariable2, constraintAnchor2.getMargin(), f6, solverVariable, constraintAnchor3.mSolverVariable, constraintAnchor3.getMargin(), 5);
                    }
                } else if (obj3 != null || constraintWidget6 == null) {
                    i6 = 8;
                    if (!(obj8 == null || constraintWidget6 == null)) {
                        obj4 = (chainHead2.mWidgetsMatchCount > 0 || chainHead2.mWidgetsCount != chainHead2.mWidgetsMatchCount) ? null : 1;
                        constraintWidget3 = constraintWidget6;
                        constraintWidget2 = constraintWidget3;
                        while (constraintWidget3 != null) {
                            ConstraintWidget constraintWidget13 = constraintWidget3.mNextChainWidget[i];
                            while (constraintWidget13 != null && constraintWidget13.getVisibility() == i6) {
                                constraintWidget13 = constraintWidget13.mNextChainWidget[i];
                            }
                            if (constraintWidget3 == constraintWidget6 || constraintWidget3 == constraintWidget7 || constraintWidget13 == null) {
                                constraintWidget12 = constraintWidget2;
                                i7 = i6;
                            } else {
                                ConstraintWidget constraintWidget14;
                                ConstraintWidget constraintWidget15 = constraintWidget13 == constraintWidget7 ? null : constraintWidget13;
                                constraintAnchor2 = constraintWidget3.mListAnchors[i2];
                                solverVariable7 = constraintAnchor2.mSolverVariable;
                                if (constraintAnchor2.mTarget != null) {
                                    solverVariable8 = constraintAnchor2.mTarget.mSolverVariable;
                                }
                                i4 = i2 + 1;
                                solverVariable8 = constraintWidget2.mListAnchors[i4].mSolverVariable;
                                margin2 = constraintAnchor2.getMargin();
                                margin3 = constraintWidget3.mListAnchors[i4].getMargin();
                                if (constraintWidget15 != null) {
                                    constraintAnchor7 = constraintWidget15.mListAnchors[i2];
                                    solverVariable5 = constraintAnchor7.mSolverVariable;
                                    solverVariable4 = constraintAnchor7.mTarget != null ? constraintAnchor7.mTarget.mSolverVariable : null;
                                } else {
                                    constraintAnchor7 = constraintWidget3.mListAnchors[i4].mTarget;
                                    solverVariable5 = constraintAnchor7 != null ? constraintAnchor7.mSolverVariable : null;
                                    solverVariable4 = constraintWidget3.mListAnchors[i4].mSolverVariable;
                                }
                                if (constraintAnchor7 != null) {
                                    margin3 += constraintAnchor7.getMargin();
                                }
                                i12 = margin3;
                                if (constraintWidget2 != null) {
                                    margin2 += constraintWidget2.mListAnchors[i4].getMargin();
                                }
                                i4 = margin2;
                                i11 = obj4 != null ? 6 : 4;
                                if (solverVariable7 == null || solverVariable8 == null || solverVariable5 == null || solverVariable4 == null) {
                                    constraintWidget14 = constraintWidget15;
                                    constraintWidget12 = constraintWidget2;
                                    i7 = 8;
                                } else {
                                    constraintWidget14 = constraintWidget15;
                                    i9 = i12;
                                    constraintWidget12 = constraintWidget2;
                                    i7 = 8;
                                    linearSystem.addCentering(solverVariable7, solverVariable8, i4, 0.5f, solverVariable5, solverVariable4, i9, i11);
                                }
                                constraintWidget13 = constraintWidget14;
                            }
                            if (constraintWidget3.getVisibility() == i7) {
                                constraintWidget3 = constraintWidget12;
                            }
                            i6 = i7;
                            constraintWidget2 = constraintWidget3;
                            constraintWidget3 = constraintWidget13;
                        }
                        constraintAnchor2 = constraintWidget6.mListAnchors[i2];
                        constraintAnchor3 = constraintWidget4.mListAnchors[i2].mTarget;
                        i4 = i2 + 1;
                        constraintAnchor4 = constraintWidget7.mListAnchors[i4];
                        constraintAnchor5 = constraintWidget5.mListAnchors[i4].mTarget;
                        if (constraintAnchor3 != null) {
                            i7 = 5;
                        } else if (constraintWidget6 != constraintWidget7) {
                            i7 = 5;
                            linearSystem2.addEquality(constraintAnchor2.mSolverVariable, constraintAnchor3.mSolverVariable, constraintAnchor2.getMargin(), 5);
                        } else {
                            i7 = 5;
                            if (constraintAnchor5 != null) {
                                linearSystem.addCentering(constraintAnchor2.mSolverVariable, constraintAnchor3.mSolverVariable, constraintAnchor2.getMargin(), 0.5f, constraintAnchor4.mSolverVariable, constraintAnchor5.mSolverVariable, constraintAnchor4.getMargin(), 5);
                            }
                        }
                        if (!(constraintAnchor5 == null || constraintWidget6 == constraintWidget7)) {
                            linearSystem2.addEquality(constraintAnchor4.mSolverVariable, constraintAnchor5.mSolverVariable, -constraintAnchor4.getMargin(), i7);
                        }
                    }
                } else {
                    obj4 = (chainHead2.mWidgetsMatchCount <= 0 || chainHead2.mWidgetsCount != chainHead2.mWidgetsMatchCount) ? null : 1;
                    constraintWidget3 = constraintWidget6;
                    constraintWidget2 = constraintWidget3;
                    while (constraintWidget3 != null) {
                        constraintWidget10 = constraintWidget3.mNextChainWidget[i];
                        while (constraintWidget10 != null) {
                            if (constraintWidget10.getVisibility() != 8) {
                                break;
                            }
                            constraintWidget10 = constraintWidget10.mNextChainWidget[i];
                        }
                        if (constraintWidget10 != null || constraintWidget3 == constraintWidget7) {
                            SolverVariable solverVariable9;
                            constraintAnchor2 = constraintWidget3.mListAnchors[i2];
                            solverVariable7 = constraintAnchor2.mSolverVariable;
                            solverVariable8 = constraintAnchor2.mTarget != null ? constraintAnchor2.mTarget.mSolverVariable : null;
                            if (constraintWidget2 != constraintWidget3) {
                                solverVariable8 = constraintWidget2.mListAnchors[i2 + 1].mSolverVariable;
                            } else if (constraintWidget3 == constraintWidget6 && constraintWidget2 == constraintWidget3) {
                                solverVariable8 = constraintWidget4.mListAnchors[i2].mTarget != null ? constraintWidget4.mListAnchors[i2].mTarget.mSolverVariable : null;
                            }
                            margin2 = constraintAnchor2.getMargin();
                            margin3 = i2 + 1;
                            i4 = constraintWidget3.mListAnchors[margin3].getMargin();
                            if (constraintWidget10 != null) {
                                constraintAnchor7 = constraintWidget10.mListAnchors[i2];
                                solverVariable5 = constraintAnchor7.mSolverVariable;
                                solverVariable9 = constraintWidget3.mListAnchors[margin3].mSolverVariable;
                            } else {
                                constraintAnchor7 = constraintWidget5.mListAnchors[margin3].mTarget;
                                solverVariable5 = constraintAnchor7 != null ? constraintAnchor7.mSolverVariable : null;
                                solverVariable9 = constraintWidget3.mListAnchors[margin3].mSolverVariable;
                            }
                            if (constraintAnchor7 != null) {
                                i4 += constraintAnchor7.getMargin();
                            }
                            if (constraintWidget2 != null) {
                                margin2 += constraintWidget2.mListAnchors[margin3].getMargin();
                            }
                            if (!(solverVariable7 == null || solverVariable8 == null || solverVariable5 == null || solverVariable9 == null)) {
                                if (constraintWidget3 == constraintWidget6) {
                                    margin2 = constraintWidget6.mListAnchors[i2].getMargin();
                                }
                                i10 = margin2;
                                i12 = constraintWidget3 == constraintWidget7 ? constraintWidget7.mListAnchors[margin3].getMargin() : i4;
                                i4 = i10;
                                solverVariable = solverVariable5;
                                solverVariable5 = solverVariable9;
                                int i13 = 4;
                                int i14 = 6;
                                i9 = i12;
                                constraintWidget12 = constraintWidget10;
                                linearSystem.addCentering(solverVariable7, solverVariable8, i4, 0.5f, solverVariable, solverVariable5, i9, obj4 != null ? 6 : 4);
                                if (constraintWidget3.getVisibility() == 8) {
                                    constraintWidget2 = constraintWidget3;
                                }
                                constraintWidget3 = constraintWidget12;
                            }
                        }
                        constraintWidget12 = constraintWidget10;
                        if (constraintWidget3.getVisibility() == 8) {
                        }
                        constraintWidget3 = constraintWidget12;
                    }
                }
                if ((obj3 == null || obj8 != null) && constraintWidget6 != null) {
                    constraintAnchor2 = constraintWidget6.mListAnchors[i2];
                    i5 = i2 + 1;
                    constraintAnchor3 = constraintWidget7.mListAnchors[i5];
                    solverVariable2 = constraintAnchor2.mTarget == null ? constraintAnchor2.mTarget.mSolverVariable : null;
                    solverVariable3 = constraintAnchor3.mTarget == null ? constraintAnchor3.mTarget.mSolverVariable : null;
                    if (constraintWidget5 != constraintWidget7) {
                        ConstraintAnchor constraintAnchor8 = constraintWidget5.mListAnchors[i5];
                        solverVariable3 = constraintAnchor8.mTarget != null ? constraintAnchor8.mTarget.mSolverVariable : null;
                    }
                    solverVariable = solverVariable3;
                    if (constraintWidget6 == constraintWidget7) {
                        constraintAnchor2 = constraintWidget6.mListAnchors[i2];
                        constraintAnchor3 = constraintWidget6.mListAnchors[i5];
                    }
                    if (solverVariable2 != null && solverVariable != null) {
                        i3 = constraintAnchor2.getMargin();
                        if (constraintWidget7 != null) {
                            constraintWidget5 = constraintWidget7;
                        }
                        linearSystem.addCentering(constraintAnchor2.mSolverVariable, solverVariable2, i3, 0.5f, solverVariable, constraintAnchor3.mSolverVariable, constraintWidget5.mListAnchors[i5].getMargin(), 5);
                        return;
                    }
                }
                return;
            }
        }
        if (obj5 != null) {
        }
        arrayList = chainHead2.mWeightedMatchConstraintsWidgets;
        if (arrayList != null) {
        }
        if (constraintWidget6 == null) {
        }
        if (obj3 != null) {
        }
        i6 = 8;
        if (chainHead2.mWidgetsMatchCount > 0) {
        }
        constraintWidget3 = constraintWidget6;
        constraintWidget2 = constraintWidget3;
        while (constraintWidget3 != null) {
        }
        constraintAnchor2 = constraintWidget6.mListAnchors[i2];
        constraintAnchor3 = constraintWidget4.mListAnchors[i2].mTarget;
        i4 = i2 + 1;
        constraintAnchor4 = constraintWidget7.mListAnchors[i4];
        constraintAnchor5 = constraintWidget5.mListAnchors[i4].mTarget;
        if (constraintAnchor3 != null) {
        }
        linearSystem2.addEquality(constraintAnchor4.mSolverVariable, constraintAnchor5.mSolverVariable, -constraintAnchor4.getMargin(), i7);
        if (obj3 == null) {
        }
        constraintAnchor2 = constraintWidget6.mListAnchors[i2];
        i5 = i2 + 1;
        constraintAnchor3 = constraintWidget7.mListAnchors[i5];
        if (constraintAnchor2.mTarget == null) {
        }
        if (constraintAnchor3.mTarget == null) {
        }
        if (constraintWidget5 != constraintWidget7) {
        }
        solverVariable = solverVariable3;
        if (constraintWidget6 == constraintWidget7) {
        }
        if (solverVariable2 != null) {
        }
    }
}
